<?php
date_default_timezone_set("America/Sao_Paulo");
require __DIR__ . "/vendor/autoload.php";

use Zanzara\ {
    Zanzara,
    Config,
    Context
};

use App\Config\Utils;

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

$config = new Config();
$config->setParseMode(Config::PARSE_MODE_MARKDOWN_LEGACY);
$config->setConnectorOptions(["dns" => "8.8.8.8"]);

$bot = new Zanzara($_ENV["BOT_TOKEN"], $config);

include __DIR__ . "/src/bot.php";

$bot->onException(function (Context $ctx, $exception) {
    $text = "Exception found!\n\n• Erro: " . Utils::cleanText($exception->getMessage()) . "\n\n• Arquivo: " . $exception->getFile() . "\n\n• Linha: " . $exception->getLine();
    $ctx->sendMessage($text, [
        "chat_id" => $_ENV["CHAT_LOGS"],
    ]);
});

$bot->run();