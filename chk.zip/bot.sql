CREATE TABLE usuario_info (
  chat_id TEXT,
  nome TEXT,
  usuario TEXT,
  saldo TEXT,
  referal TEXT,
  adm TEXT,
  ccs TEXT,
  mix TEXT,
  recarga_manual TEXT,
  recarga_pix TEXT,
  pontos TEXT,
  banido TEXT,
  cadastrado TEXT,
  gifts TEXT
);

CREATE TABLE dados_pix (
 token TEXT,
 tempo TEXT,
 min TEXT,
 max TEXT, 
 banco TEXT
);

CREATE TABLE textos (
 tipo TEXT,
 texto TEXT
);

CREATE TABLE login_site (
 login TEXT,
 senha TEXT
);

CREATE TABLE gates (
 id TEXT,
 link TEXT,
 aprovada TEXT,
 reprovada TEXT
);

CREATE TABLE config (
 id TEXT,
 gate TEXT,
 suporte TEXT,
 manutencao TEXT
);

CREATE TABLE pix (
 chat_id TEXT,
 id_pix TEXT,
 valor TEXT,
 status TEXT,
 data TEXT
);

CREATE TABLE ccs (
 cc TEXT,
 lista TEXT,
 nivel TEXT,
 bandeira TEXT,
 tipo TEXT,
 banco TEXT,
 pais TEXT,
 bin TEXT
);

CREATE TABLE preco (
 nivel TEXT,
 valor TEXT
);

CREATE TABLE mix (
 id TEXT,
 mix TEXT,
 quantidade TEXT,
 valor TEXT
);

CREATE TABLE login (
 login TEXT,
 senha TEXT,
 cidade TEXT,
 valor TEXT,
 tipo TEXT
);

CREATE TABLE hist_login (
 login TEXT,
 senha TEXT,
 cidade TEXT,
 valor TEXT,
 tipo TEXT,
 id_user TEXT
);

CREATE TABLE hist_ccs (
 cc TEXT,
 preco TEXT,
 user_id TEXT,
 lista TEXT,
 nomecpf TEXT,
 level TEXT,
 hour TEXT
);
 

CREATE TABLE gift (
 gift TEXT,
 valor TEXT,
 resgate TEXT,
 usuario_resgate TEXT,
 data_resgate TEXT,
 hora_resgate TEXT
);
 