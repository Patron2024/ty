<?php

namespace App\Db;

class Conn
{
    public static function get() {
         $host = $_ENV["HOST"];
        $user = $_ENV["DB_USER"];
        $pass = $_ENV["DB_PASS"];
        $db = $_ENV["DB_NAME"];
        
        $charset = 'utf8mb4';
        
        $dsn = "mysql:host=$host;dbname=$db;charset=$charset";

        try {
            $pdo = new \PDO($dsn, $user, $pass);
            $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);

            return $pdo;
        } catch (\PDOException $e) {
            echo "Erro de conexão: " . $e->getMessage(); // Mostra a mensagem de erro
            return null; // Retornar null em caso de erro de conexão
        }
    }
}
?>