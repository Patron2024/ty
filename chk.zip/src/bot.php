<?php

use Zanzara\Context;
use App\Telegram\Command;
use App\Telegram\Callbacks;

$bot->onMessage(function (Context $ctx) {
    $text = $ctx->getMessage()->getText();
    $command = new Command($text);
    $command->handler($ctx);
});

$bot->onCbQuery(function (Context $ctx) {
    $main = $ctx->getCallbackQuery()->getData();

    $user_id = $ctx
    ->getUpdate()
    ->getEffectiveUser()
    ->getId();

    $from_id = $ctx
    ->getCallbackQuery()
    ->getMessage()
    ->getReplyToMessage()
    ->getFrom()
    ->getId();

    if ($user_id == $from_id) {
        $callbacks = new Callbacks($main);
        $callbacks->handler($ctx);
    } else {
        $ctx->answerCallbackQuery([
            "show_alert" => true,
            "text" => "⚠️ Você não tem permissão!",
        ]);
    }
});