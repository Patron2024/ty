<?php

namespace App\Config;

class Utils
{
  public static function cleanText($str)
  {
    return self::RemoveNoAlpha(self::QuitHtml($str));
  }

  public static function QuitHtml(?string $str)
  {
    return @str_replace(
      ["<", ">", "≤", "≥"],
      ["&lt;", "&gt;", "&le;", "&ge;"],
      $str
    );
  }

  public static function RemoveNoAlpha(?string $str = null): ?string
  {
    if (is_null($str)) {
      return null;
    }
    return preg_replace("/[^a-zA-Z0-9\s]/", " ", $str);
  }
}
