<?php

namespace App\Controller;

use App\Db\Conn;

class Controller
{
    public static function scan(?int $id, string $nome, string $username): array
    {
        try {
            $pdo = Conn::get();
            $stmt = $pdo->prepare("SELECT * FROM usuario_info WHERE chat_id = :chat_id");
            $stmt->bindParam(":chat_id", $id, \PDO::PARAM_INT);
            $stmt->execute();

            $fetch = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            if (empty($fetch)) {
                $dataatual = date("Y-m-d H:i:s");
                $stmt = $pdo->prepare("INSERT INTO usuario_info (chat_id, nome, usuario, saldo, referal, adm, ccs, mix, recarga_manual, recarga_pix, pontos, banido, cadastrado, gifts) VALUES (:chat_id, :nome, :usuario, :saldo, :referal, :adm, :ccs, :mix, :recarga_manual, :recarga_pix, :pontos, :banido, :cadastrado, :gifts)");
                $stmt->bindValue(':chat_id', $id, \PDO::PARAM_INT);
                $stmt->bindValue(':nome', $nome, \PDO::PARAM_STR);
                $stmt->bindValue(':usuario', $username, \PDO::PARAM_STR);
                $stmt->bindValue(':saldo', 0.00, \PDO::PARAM_STR);
                $stmt->bindValue(':referal', null, \PDO::PARAM_NULL);
                $stmt->bindValue(':adm', 'false', \PDO::PARAM_STR);
                $stmt->bindValue(':ccs', 0, \PDO::PARAM_INT);
                $stmt->bindValue(':mix', 0, \PDO::PARAM_INT);
                $stmt->bindValue(':recarga_manual', 0, \PDO::PARAM_INT);
                $stmt->bindValue(':recarga_pix', 0, \PDO::PARAM_INT);
                $stmt->bindValue(':pontos', 0, \PDO::PARAM_INT);
                $stmt->bindValue(':banido', 'false', \PDO::PARAM_STR);
                $stmt->bindValue(':cadastrado', $dataatual);
                $stmt->bindValue(':gifts', 0, \PDO::PARAM_INT);
                $stmt->execute();

                if ($stmt->rowCount() == 0) {
                    return [
                        "status" => false,
                        "message" => "Não foi possível registrar sua conta, contate o desenvolvedor.",
                    ];
                }
            } else {
                // O que fazer se já existir registro
            }

            return [
                "status" => true,
            ];

        } catch (\PDOException $e) {
            return [
                "status" => false,
                "message" => "Erro de banco de dados: " . $e->getMessage(),
            ];
        } catch (\Exception $e) {
            return [
                "status" => false,
                "message" => "Erro: " . $e->getMessage(),
            ];
        }
    }

    public static function getAll(): array
    {
        try {
            $pdo = Conn::get();
            $stmt = $pdo->prepare("SELECT * FROM usuario_info");
            $stmt->execute();

            return $stmt->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\PDOException $e) {
            return [
                "status" => false,
                "message" => "Erro de banco de dados: " . $e->getMessage(),
            ];
        } catch (\Exception $e) {
            return [
                "status" => false,
                "message" => "Erro: " . $e->getMessage(),
            ];
        }
    }
}