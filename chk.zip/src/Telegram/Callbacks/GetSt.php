<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;
use App\Db\Conn;
use \PDO;

class GetSt
{
    public bool $prt = true;

    public function handler(Context $ctx, $parameter): bool {
        $chat_id = $ctx->getEffectiveChat()->getId();
        $admin = $_ENV["ADMIN"] ?? ''; // Certifique-se de que a variável de ambiente 'ADMIN' está configurada 
        
        if ($chat_id == $admin) {
            $pdo = Conn::get();
            
            $data = date("Y-m-d"); // Formato da data atualizado para Y-m-d

            // Contagem de vendas de ccs
            $stmtCC15 = $pdo->prepare("SELECT COUNT(*) FROM hist_ccs WHERE hour >= DATE_SUB(NOW(), INTERVAL 15 DAY)");
            $stmtCC15->execute();
            $cc15Dias = $stmtCC15->fetchColumn();

            $stmtCC7 = $pdo->prepare("SELECT COUNT(*) FROM hist_ccs WHERE hour >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
            $stmtCC7->execute();
            $cc7Dias = $stmtCC7->fetchColumn();

            $stmtCCHoje = $pdo->prepare("SELECT COUNT(*) FROM hist_ccs WHERE DATE(hour) = :data");
            $stmtCCHoje->bindParam(":data", $data);
            $stmtCCHoje->execute();
            $cchoje = $stmtCCHoje->fetchColumn();

            // Contagem de cadastros de usuários
            $stmtUsers15 = $pdo->prepare("SELECT COUNT(*) FROM usuario_info WHERE cadastrado >= DATE_SUB(NOW(), INTERVAL 15 DAY)");
            $stmtUsers15->execute();
            $users15Dias = $stmtUsers15->fetchColumn();

            $stmtUsers7 = $pdo->prepare("SELECT COUNT(*) FROM usuario_info WHERE cadastrado >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
            $stmtUsers7->execute();
            $users7Dias = $stmtUsers7->fetchColumn();

            $stmtUsersHoje = $pdo->prepare("SELECT COUNT(*) FROM usuario_info WHERE DATE(cadastrado) = :data");
            $stmtUsersHoje->bindParam(":data", $data);
            $stmtUsersHoje->execute();
            $usrshoje = $stmtUsersHoje->fetchColumn();

            $message_id = $ctx->getUpdate()->getCallbackQuery()->getMessage()->getMessageId();

            $mensagem = "✅ RELATÓRIO DO BOT:\n\n";
            $mensagem .= "💳 VENDA DE CCS:\n";
            $mensagem .= "Últimos 15 Dias: $cc15Dias\n";
            $mensagem .= "Últimos 7 Dias: $cc7Dias\n";
            $mensagem .= "Vendas Hoje: $cchoje\n\n";
            $mensagem .= "👤CADASTRO DE USERS:\n";
            $mensagem .= "Últimos 15 Dias: $users15Dias\n";
            $mensagem .= "Últimos 7 Dias: $users7Dias\n";
            $mensagem .= "Cadastros Hoje: $usrshoje";

            $buttons[] = ['text' => "ADMIN", 'callback_data' => "admin"];
            $menu['inline_keyboard'] = array_chunk($buttons, 2);

            $ctx->sendMessage("$mensagem", ["reply_to_message_id" => $message_id, "parse_mode" => 'Markdown', "reply_markup" => $menu]);
        }
    }
}

?>