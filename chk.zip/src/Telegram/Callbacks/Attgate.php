<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;
use App\Db\Conn;
use \PDO;

class Attgate {
    public bool $prt = true;

    public function handler(Context $ctx) {
        $parameter = $ctx->getCallbackQuery()->getData();

        $param_parts = explode(" ", $parameter);

        if (count($param_parts) < 2) {
            $ctx->sendMessage("Formato de parâmetro incorreto.");
            return false;
        }

        $status = $param_parts[1];

        $pdo = Conn::get();
        $id = "config";
        $stmt = $pdo->prepare("UPDATE config SET gate = :gate WHERE id = :id");
        $stmt->bindParam(":gate", $status, PDO::PARAM_STR);
        $stmt->bindParam(":id", $id, PDO::PARAM_STR);
        $stmt->execute();

        $txt = "GATE SELECIONADA: $status";

        $options = ["text" => $txt, "show_alert" => true]; 
        $ctx->answerCallbackQuery($options);
    }
}
?>