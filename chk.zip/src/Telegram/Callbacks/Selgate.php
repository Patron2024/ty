<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;
use App\Db\Conn;
use \PDO;

class Selgate {
    public bool $prt = false;

    public function handler(Context $ctx) {
        $admin = $_ENV["ADMIN"] ?? ''; // Certifique-se de que a variável de ambiente 'ADMIN' está configurada 
        $chat_id = $ctx->getEffectiveChat()->getId();
        $message_id = $ctx->getUpdate()->getCallbackQuery()->getMessage()->getMessageId();
        
        if ($chat_id == $admin) {
            $pdo = Conn::get();

            $stmt = $pdo->prepare("SELECT * FROM gates");
            $stmt->execute();
            
            $gates = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $button = []; // Inicializa o array $button
            
            foreach ($gates as $gate) {
                $button[] = ["text" => $gate['id'], // Suponho que 'nome' seja o campo no banco de dados que deseja exibir
                             "callback_data" => "attgate {$gate['id']}"]; // Supondo que 'id' seja o identificador único do gate
            }
            $configValue = "config";
        $stmtt = $pdo->prepare("SELECT * FROM config WHERE id = :chat_id");
$stmtt->bindParam(":chat_id", $configValue, \PDO::PARAM_STR); // Substitua $configValue pelo valor desejado
$stmtt->execute();
$fetch2 = $stmtt->fetchAll(\PDO::FETCH_ASSOC);
            $button[] = ["text" => "🔙 VOLTA",
            "callback_data" => "admin"];
            $menu["inline_keyboard"] = array_chunk($button, 1);
    
            $txt = "MENU DE SELECIONAR GATES

GATE ATUAL: ".$fetch2[0]["gate"]." "; // Defina o texto a ser exibido ou modificado
            
            $ctx->editMessageText($txt, [
                "reply_markup" => $menu,
            ]);
        }
    }
}
?>