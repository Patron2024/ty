<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;
use App\Db\Conn;
use \PDO;

class Getmanu {
    public bool $prt = false;

    public function handler(Context $ctx) {
        $admin = $_ENV["ADMIN"] ?? ''; // Certifique-se de que a variável de ambiente 'ADMIN' está configurada 
        $chat_id = $ctx->getEffectiveChat()->getId();

        if ($chat_id == $admin) {
            $txt = "ATIVE OU DESATIVE A MANUTENÇÃO USANDO O MENU ABAIXO!!!";

            // Definição dos valores 'true' e 'false' como strings
            $true = "true";
            $false = "false";

            // Criação dos botões com os valores corretos de 'true' e 'false'
            $buttons[] = ['text' => "✅ ATIVAR", 'callback_data' => "attmanu true"];
            $buttons[] = ['text' => "❌ DESATIVAR", 'callback_data' => "attmanu false"];
            $buttons[] = ['text' => "🔙 VOLTAR", 'callback_data' => "admin"];
            $menu['inline_keyboard'] = array_chunk($buttons, 1);

            $ctx->editMessageText($txt, [
                "reply_markup" => $menu,
            ]);
        }
    }
}