<?php

namespace App\Telegram\Callbacks;

use App\Db\Conn;
use Zanzara\Context;

class Trocarpontos
{
    public bool $prt = false;

    public function handler(Context $ctx) {
        $pdo = Conn::get();

        // Obter o chat_id do usuário
        $chat_id = $ctx->getUpdate()->getCallbackQuery()->getMessage()->getChat()->getId();

        // Verificar a quantidade de pontos e saldo do usuário usando o chat_id
        $stmt = $pdo->prepare("SELECT pontos, saldo FROM usuario_info WHERE chat_id = :chat_id");
        $stmt->bindParam(":chat_id", $chat_id, \PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch();

        if ($result) {
            $pontos = $result['pontos'];
            $saldo_antigo = $result['saldo'];

            // Converter pontos em saldo (2 pontos = 1 de saldo)
            $saldo_ganho = floor($pontos / 2);
            $novo_saldo = $saldo_antigo + $saldo_ganho;
            $pontos_restantes = $pontos % 2; // Pontos restantes que não foram convertidos

            // Atualizar o saldo e os pontos no banco de dados
            $stmtUpdate = $pdo->prepare("UPDATE usuario_info SET saldo = :novo_saldo, pontos = :pontos_restantes WHERE chat_id = :chat_id");
            $stmtUpdate->bindParam(":novo_saldo", $novo_saldo, \PDO::PARAM_INT);
            $stmtUpdate->bindParam(":pontos_restantes", $pontos_restantes, \PDO::PARAM_INT);
            $stmtUpdate->bindParam(":chat_id", $chat_id, \PDO::PARAM_INT);
            $stmtUpdate->execute();

            // Enviar mensagem com os detalhes da atualização
            $txt = "✅ OPA UM TOTAL DE $pontos FOI ATUALIZADO, VOCÊ GANHOU R$ $saldo_ganho DE SALDO";
            $button[] = ["text" => "🔙 VOLTA",
                "callback_data" => "infov2"];

            $menu["inline_keyboard"] = array_chunk($button, 1);

            $ctx->editMessageText($txt, [
                "reply_markup" => $menu,
            ]);
        }
    }
}

?>