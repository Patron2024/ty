<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;
use App\Db\Conn;
use \PDO;

class Attmanu
{
    public bool $prt = true;

    public function handler(Context $ctx) {
        $parameter = $ctx->getCallbackQuery()->getData();

        $param_parts = explode(" ", $parameter);

        if (count($param_parts) < 1) {
            $ctx->sendMessage("Formato de parâmetro incorreto.");
            return false;
        }

        $status = $param_parts[1] === 'true' ? "true" : "false"; // Convertendo 'true' em 1 e 'false' em 0

        $pdo = Conn::get();
        $id = "config";
        $stmt = $pdo->prepare("UPDATE config SET manutencao = :manu WHERE id = :id");
        $stmt->bindParam(":manu", $status, PDO::PARAM_STR); // Alterei para PDO::PARAM_INT para inserir um inteiro
        $stmt->bindParam(":id", $id, PDO::PARAM_STR);
        $stmt->execute();

        $teste = $param_parts[1] === 'true' ? "Ativada" : "Desativada"; 
        $txt = "STATUS DA MANUTENÇÃO: $teste";

        $options = ["text" => $txt, "show_alert" => true]; 
        $ctx->answerCallbackQuery($options);
    }
}
?>