<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;
use App\Db\Conn;
use \PDO;

class chklog
{
    public bool $prt = true;

    public function handler(Context $ctx, $parameter): bool {
        $cc = intval(explode(" ", $parameter)[1]);
        $preco = intval(explode(" ", $parameter)[2]);
        $data = $ctx->getEffectiveChat()->getTitle(); // Ajuste conforme necessário
        
        $chat_id = $ctx->getEffectiveChat()->getId();

        $pdo = Conn::get();
        
        $stmt = $pdo->prepare("SELECT * FROM usuario_info WHERE chat_id = :chat_id");
        $stmt->bindParam(":chat_id", $chat_id, \PDO::PARAM_INT);
        $stmt->execute();

        $fetchuser = $stmt->fetch();
      
        if (!empty($fetchuser) && $fetchuser['banido'] === 'true') {
            echo "Usuário bloqueado, retornando ao menu";
            $ctx->sendMessage("❌ VC TA BANIDO CONTATE O SUPORTE");          
            return false;
        }
         
        $saldo = $fetchuser['saldo'];
        $newSaldo = $saldo - $preco;

        if ($preco > $saldo || $newSaldo < 0) {
            $txt = "💰 | Saldo Insuficiente";
            $options = ["text" => $txt, "show_alert" => true]; 
            $ctx->answerCallbackQuery($options);
            return false; // Indica que o saldo é insuficiente para a compra
        }

        $stmt = $pdo->prepare("SELECT * FROM login WHERE tipo = :nivel LIMIT 1");
        $stmt->bindParam(":nivel", $cc, \PDO::PARAM_INT);
        $stmt->execute();

        $ccs = $stmt->fetch();
    
        $nivel = $ccs['tipo'];
  
        $login = $ccs['login'];
        $senha = $ccs['senha'];
        $cidade = $fetchuser['cidade'];
  
        if (!$this->debitarSaldo($preco, $chat_id, $pdo)) {
            $txt = "🚨 | Compra não realizada, seu saldo não foi debitado!";
            $options = ["text" => $txt, "show_alert" => true]; 
            $ctx->answerCallbackQuery($options);
            return false;
        }
  
        $newSaldo = $saldo - $preco;

        $txt = "*🛒 COMPRA EFETUADA!*\n\n*✨ Detalhes do login*\n\n*Login*: $login\n*Senha*: $senha\n*Cidade*: $cidade\n*Tipo*: $nivel\n\n💸 *Valor: R$ $preco*\n💰 *Novo Saldo: R$ $newSaldo*";

        $message_id = $ctx->getCallbackQuery()->getMessage()->getMessageId();
        
        $stmt = $pdo->prepare("DELETE FROM login WHERE login = :cc");
        $stmt->bindParam(':cc', $login, \PDO::PARAM_STR);
        $stmt->execute();
        
        $ctx->editMessageText($txt, [
            "chat_id" => $chat_id,
            "message_id" => $message_id, 
            "parse_mode" => "Markdown"
        ]);
    
        $stmt = $pdo->prepare("INSERT INTO hist_login (id_user, valor, login, senha, cidade, tipo) VALUES (:user_id, :preco, :login, :senha, :cidade, :tipo)");
        $stmt->bindParam(':user_id', $chat_id, \PDO::PARAM_STR);
        $stmt->bindParam(':preco', $preco, \PDO::PARAM_STR);
        $stmt->bindParam(':login', $login, \PDO::PARAM_STR);
        $stmt->bindParam(':senha', $senha, \PDO::PARAM_STR);
        $stmt->bindParam(':cidade', $cidade, \PDO::PARAM_STR);
        $stmt->bindParam(':tipo', $nivel, \PDO::PARAM_STR);
        $stmt->execute();
    
        $this->NotificarVendaLogin($ctx, $chat_id, $preco, $nivel);
    
        return true;
    }

    private function debitarSaldo($preco, $chat_id, $pdo) {
        $stmt = $pdo->prepare("SELECT saldo FROM usuario_info WHERE chat_id = :chat_id");
        $stmt->bindParam(":chat_id", $chat_id, \PDO::PARAM_INT);
        $stmt->execute();
        $fetch = $stmt->fetch();
        
        $current_balance = $fetch['saldo'];
        $new_balance = $current_balance - $preco;
        
        $stmt_update = $pdo->prepare("UPDATE usuario_info SET saldo = :saldo WHERE chat_id = :chat_id");
        $stmt_update->bindParam(':saldo', $new_balance, \PDO::PARAM_INT);
        $stmt_update->bindParam(':chat_id', $chat_id, \PDO::PARAM_INT);
        
        return $stmt_update->execute(); // Retorna true se a atualização for bem-sucedida
    }

    private function NotificarVendaLogin(Context $ctx, $chat_id, $preco, $tipo): void {
        $txt = "✅ NOVA LOGIN VENDIDA COM SUCESSO\n\TIPO: $tipo\nPRECO: $preco\n\nID DO COMPRADOR: $chat_id\n\n🏆 STORE NÚMERO 1⁰ EM VENDAS!!!";

        $chat_msg = $_ENV["CHAT_NOTF"] ?? ''; 
        $ctx->sendMessage($txt, [
            "chat_id" => $chat_msg,
            "parse_mode" => "Markdown",
            "disable_web_page_preview" => true
        ]);
    }
}