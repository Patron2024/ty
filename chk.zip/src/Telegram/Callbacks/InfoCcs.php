<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;
use App\Db\Conn;
use \PDO;

class InfoCcs
{
    public bool $prt = false;

    public function handler(Context $ctx) {
        $pdo = Conn::get();
        
$stmt = $pdo->prepare("SELECT * FROM ccs");
$stmt->execute();
$ccs = $stmt->fetchAll();
        
if (empty($ccs)) {
    $txt = "⚠️ | Base está sem informações!";
    $options = ["text" => $txt, "show_alert" => true]; 
    $ctx->answerCallbackQuery($options);
    return;
}

$buttons = [];
$levels = [];
$lvl = ''; // Inicializar a variável $lvl aqui para que não seja sobrescrita no loop

foreach ($ccs as $cc) {
    $nivel = $cc['nivel'];

    // Se esse nível já foi tratado, pule para o próximo
    if (array_key_exists($nivel, $levels)) {
        continue;
    }

    $stmt = $pdo->prepare("SELECT * FROM preco WHERE nivel = :nivel");
    $stmt->bindParam(":nivel", $nivel, PDO::PARAM_STR);
    $stmt->execute();

    $fetchpreco = $stmt->fetch();
        
    $price = (!empty($fetchpreco['valor']) ? $fetchpreco['valor'] : 7);
    $levels[$nivel] = $price;
}

$buttons = [];
$lvl = '';

foreach ($levels as $nivel => $price) {
    $lvl .= "$nivel | (R$ $price)\n";
    // Supondo que queremos manter a estrutura do botão como no seu código original
    $buttons[] = ['text' => "$nivel | (R$ $price)", 'callback_data' => "chkcc $nivel $price"];
}
$buttons[] = ['text'=>"",'callback_data'=>"."];
$buttons[] = ['text' => '↩️ VOLTAR', 'callback_data' => 'menu'];

$txt = "✨ *Escolha um nível/level para prosseguir:*\n\n$lvl"; // Adicionar todos os níveis ao texto

        $menu['inline_keyboard'] = array_chunk($buttons, 2);
        
        $chat_id = $ctx->getEffectiveChat()->getId();
        $message_id = $ctx->getCallbackQuery()->getMessage()->getMessageId();
        
        $ctx->editMessageText($txt, [
            "chat_id" => $chat_id,
            "message_id" => $message_id,
            "reply_markup" => $menu,
            "parse_mode" => 'Markdown'
        ]);
    }
}