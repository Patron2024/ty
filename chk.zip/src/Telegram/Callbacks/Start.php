<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;

class Start
{
    public bool $prt = false;

    public function handler(Context $ctx) {
        $nome = $ctx->getEffectiveUser()->getFirstName();

        $txt = "🚀 BEM VINDO $nome A MELHOR BASE DE CCS

[REFERÊNCIAS](t.me/PaivaStore)
[SUPORTE](t.me/PaivaCcs)

✅ GARANTIRMOS LIVE
❌ NÃO GARANTIRMOS SALDO

✅ PIX AUTOMÁTICO 
Exemplo: /pix 10
✅ CHECKER ONLINE
✅ TROCAS EM ATE 10 MINUTOS";        
        $button[] = ["text" => "👤 INFO",
            "callback_data" => "infov2"];
            $button[] = ["text" => "⚙️ DEV",
            "callback_data" => "dev"];
            $button[] = ["text" => "ℹ️ MENU",
            "callback_data" => "menu"];

        $menu["inline_keyboard"] = array_chunk($button, 1);

        $ctx->editMessageText($txt, [
            "reply_markup" => $menu,
        ]);
    }
}