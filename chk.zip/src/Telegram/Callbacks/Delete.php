<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;

class Delete
{
    public bool $prt = true;

    public function handler(Context $ctx, $parameter) {
        $message_id = intval(explode(" ", $parameter)[1]);
        $chat_id = intval(explode(" ", $parameter)[2]);
        $ctx->deleteMessage($chat_id, $message_id);
        $message_id = intval(explode(" ", $parameter)[3]);
            $ctx->deleteMessage($chat_id, $message_id);
        }
    }