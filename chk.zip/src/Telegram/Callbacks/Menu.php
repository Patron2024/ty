<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;

class Menu
{
    public bool $prt = false;

    public function handler(Context $ctx) {
        $nome = $ctx->getEffectiveUser()->getFirstName();
        $txt = "📁 MENU DE COMPRAS\n\nOBS: Próximas Atualização Terar Mais botões!!!";

        $button[] = ["text" => "💳 CCS",
            "callback_data" => "InfoCcs"];
           $button[] = ["text" => "💳 MIX",
            "callback_data" => "mix"];
            $button[] = ["text" => "🎟️ LOGINS",
            "callback_data" => "infologin"];
            $button[] = ['text'=>"🔎 PESQUISA", 'callback_data'=>"pesquisa"];
            $button[] = ["text" => "🔙 VOLTA",
            "callback_data" => "start"];
        
        $menu["inline_keyboard"] = array_chunk($button, 2);

        $ctx->editMessageText($txt, [
            "reply_markup" => $menu,
        ]);
    }
}