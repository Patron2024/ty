<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;
use App\Db\Conn;
use \PDO;

class Chkpixv2
{
    public bool $prt = true;

    public function handler(Context $ctx, $parameter): bool {
        $id_pix = intval(explode(" ", $parameter)[1]);
        $amount = intval(explode(" ", $parameter)[2]);
        $chat_id = $ctx->getEffectiveChat()->getId();
        $banco = "MercadoPago";
        $pdo = Conn::get();

        $stmt = $pdo->prepare("SELECT * FROM dados_pix WHERE banco = :banco");
        $stmt->bindParam(":banco", $banco, \PDO::PARAM_STR);
        $stmt->execute();

        $fetch = $stmt->fetch();
        $token = $fetch['token'] ?? '';

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://pladixoficial.com.br/mercadoPago/checkPix.php?accessToken=" . $token . "&payment_id=" . $id_pix,
            CURLOPT_RETURNTRANSFER => true,
        ]);

        $exec = curl_exec($curl);
        $exec = json_decode($exec, true);
        $message = $exec["message"];
        
        $txt = "ID: $id_pix | VALOR: $amount | STATUS $message";
        echo "$txt";
        
        if ($message === "Pago") {
            $txt = "✅ PAGAMENTO RECEBIDO COM SUCESSO, BOAS COMPRAS";
            $ctx->editMessageText($txt, [
                "chat_id" => $chat_id,
            ]);

            $status = "approved";
            $stmt = $pdo->prepare("UPDATE pix SET status = :status WHERE id_pix = :id_pix");
            $stmt->bindParam(':status', $status, \PDO::PARAM_STR);
            $stmt->bindParam(':id_pix', $id_pix, \PDO::PARAM_INT);
            $stmt->execute();

            $this->notificarPix($ctx, $chat_id, $amount);
            $this->addSaldo($pdo, $chat_id, $amount);
        } elseif ($message === "Pagamento Pendente") {
            $txt = "⚠️ PAGAMENTO PENDENTE";
            $options = ["text" => $txt, "show_alert" => true]; 
            $ctx->answerCallbackQuery($options);
            
        } else {
            $txt = "❌ | Seu pagamento expirou! | $status";
            $options = ["text" => $txt, "show_alert" => true]; 
            $ctx->answerCallbackQuery($options);

            $status = "expired";
            $stmt = $pdo->prepare("UPDATE pix SET status = :status WHERE id_pix = :id_pix");
            $stmt->bindParam(':status', $status, \PDO::PARAM_STR);
            $stmt->bindParam(':id_pix', $id_pix, \PDO::PARAM_INT);
            $stmt->execute();
        }
        return true;
    }

    private function addSaldo(PDO $pdo, $chat_id, $amount): void {
    	echo "addaaldo | $chat_id | $amount";
    $pdo1 = Conn::get();
    $stmt = $pdo1->prepare("SELECT saldo FROM usuario_info WHERE chat_id = :chat_id");
    $stmt->bindParam(":chat_id", $chat_id, \PDO::PARAM_INT);
    $stmt->execute();
    $fetch = $stmt->fetch();
    $current_balance = $fetch['saldo'];
    
    // Adiciona o novo saldo ao saldo existente
    $new_balance = $current_balance + $amount;

    $stmt = $pdo1->prepare("UPDATE usuario_info SET saldo = :saldo WHERE chat_id = :chat_id");
    $stmt->bindParam(':saldo', $new_balance, \PDO::PARAM_INT);
    $stmt->bindParam(':chat_id', $chat_id, \PDO::PARAM_INT);
    $stmt->execute();
}

private function notificarPix(Context $ctx, $chat_id, $amount): void {
	echo "notfrec | $chat_id | $amount";
    $txt = "✅ NOVA RECARGA PIX EFETUADA\n\nID: $chat_id\nVALOR: $$amount\n\n[ADICIONE SALDO TAMBÉM](t.me/patrondvs)";
    $chat_msg = $_ENV["CHAT_NOTF"] ?? ''; 
    $ctx->sendMessage($txt, [
        "chat_id" => $chat_msg,
        "parse_mode" => "Markdown",
        "disable_web_page_preview" => true
    ]);
}
}