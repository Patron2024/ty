<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;

class Dev
{
    public bool $prt = false;

    public function handler(Context $ctx) {
        $txt = "ℹ️ INFORMAÇÕES SOBRE O DESCOBRIMENTO

⏰ DATA DE INÍCIO DA CRIAÇÃO: 18/MARCO/2024

✅ ESTE BOT E COMPLETO E USA PHP POLLING E SQL DE BASE DE DADOS!!!";

        $button[] = ["text" => "📁 MAIS INFORMAÇÕES",
            "url" => "t.me/PatronDevelop"];
        $button[] = ["text" => "⚙️ DESENVOLVEDOR",
            "url" => "t.me/PatronDvs"];

        $button[] = ["text" => "🔙 VOLTA",
            "callback_data" => "start"];

        $menu["inline_keyboard"] = array_chunk($button, 1);

        $ctx->editMessageText($txt, [
            "reply_markup" => $menu,
        ]);
    }
}