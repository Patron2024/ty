<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;
use App\Db\Conn;
use \PDO;

class chkcc
{
    public bool $prt = true;

    public function handler(Context $ctx, $parameter): bool {
        $cc = intval(explode(" ", $parameter)[1]);
        $preco = intval(explode(" ", $parameter)[2]);
        $data = $ctx->getEffectiveChat()->getTitle(); // Ajuste conforme necessário
        
        $chat_id = $ctx->getEffectiveChat()->getId();

        $pdo = Conn::get();
        
        $stmt = $pdo->prepare("SELECT * FROM usuario_info WHERE chat_id = :chat_id");
        $stmt->bindParam(":chat_id", $chat_id, \PDO::PARAM_STR);
        $stmt->execute();

        $fetchuser = $stmt->fetch();
      
        if (!empty($fetch[0]) && $fetch[0]["banido"] === 'true') {
        echo "user bloqueado ta no menu";
        $ctx->sendMessage("❌ VC TA BANIDO CONTATE @PAIVACCS");          
            return false;
    }
         
        $saldo = $fetchuser['saldo'];
        $newSaldo = $saldo - $preco;

        if ($preco > $saldo || $newSaldo < 0) {
            $txt = "💰 | Saldo Insuficiente";
            $options = ["text" => $txt, "show_alert" => true]; 
            $ctx->answerCallbackQuery($options);
            return false; // Indica que o saldo é insuficiente para a compra
        }

        $stmt = $pdo->prepare("SELECT * FROM ccs WHERE nivel = :nivel LIMIT 1");
$stmt->bindParam(":nivel", $cc, \PDO::PARAM_INT);
$stmt->execute();

$ccs = $stmt->fetch();

$lista = $ccs['lista'];
        
      echo "lista ok: $lista";

  
            
            $ch = curl_init();
            
            $configValue = "config";
       $stmtt = $pdo->prepare("SELECT * FROM config WHERE id = :chat_id");
$stmtt->bindParam(":chat_id", $configValue, \PDO::PARAM_STR); // Substitua $configValue pelo valor desejado
$stmtt->execute();
$fetch2 = $stmtt->fetchAll(\PDO::FETCH_ASSOC);

$gate = "".$fetch2[0]["gate"]."";

$sqllc = $pdo->prepare("SELECT * FROM gates WHERE id = :gate");
$sqllc->bindParam(":gate", $gate, \PDO::PARAM_STR); // Substitua $gate pelo valor desejado
$sqllc->execute();
$fetch3 = $sqllc->fetchAll(\PDO::FETCH_ASSOC);
  
$link = "".$fetch3[0]["link"]."";
$aprovada = "".$fetch3[0]["aprovada"]."";

$link = str_replace("{card}", $lista, $link);

echo "link $link | aprovada $aprovada";

curl_setopt($ch, CURLOPT_URL, $link);

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");

curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36 OPR/104.0.0.0');

curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

curl_setopt($ch, CURLOPT_ENCODING, "gzip");

curl_setopt($ch, CURLOPT_HTTPHEADER, array());

$resultado = curl_exec($ch);
echo "se: $resultado";

if (strpos($resultado, $aprovado) !== false) {
	  $nivel = $ccs['nivel'];
      $stmt = $pdo->prepare("SELECT * FROM preco WHERE nivel = :nivel");
        $stmt->bindParam(":nivel", $nivel, \PDO::PARAM_STR);
        $stmt->execute();

       $fetchpreco = $stmt->fetch();
        
      $preco = (!empty($fetchpreco['valor']) ? $fetchpreco['valor'] : 7);
    /* Comprou - Vamos ver se pode debitar o saldo */
 if (!$this->debitarSaldo($preco, $chat_id)) {
    $txt = "🚨 | Compra não realizada, seu saldo não foi debitado!";
    $options = ["text" => $txt, "show_alert" => true]; 
    $ctx->answerCallbackQuery($options);
}
    /* Fim */
    /* Vamos tentar setar os pontos do cliente */
    
    /* Fim */
    $cc = explode("|", $lista)[0];
    $mes = explode("|", $lista)[1];
    $ano = explode("|", $lista)[2];
    $cvv = explode("|", $lista)[3];

   $bandeira = $ccs['bandeira'];
        $tipo = $ccs['tipo'];
        $banco = $ccs['banco'];
        $pais = $ccs['pais'];
        
     $saldo = $fetchuser['saldo'];
      

   $newSaldo = $saldo - $preco;


   
    $i = date("i") + 10;
    $ch = curl_init(); 

curl_setopt($ch, CURLOPT_URL, "http://bet.patronhost.online/api_dados1.php"); 

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 

curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 

curl_setopt($ch, CURLOPT_ENCODING, "gzip"); 

curl_setopt($ch, CURLOPT_POST, false); 

curl_setopt($ch, CURLOPT_POSTFIELDS, 'acao=gerar_pessoa&sexo=I&pontuacao=S&idade=0&cep_estado=&txt_qtde=1&cep_cidade='); 

$dados = curl_exec($ch); 

$dados1 = json_decode($dados, true); 

$nome = $dados1["nome"]; 

$cpf = $dados1["cpf"]; 

    $txt = "*🛒 COMPRA EFETUADA!*\n\n*✨ Detalhes do cartão*\n\n💳 *Cartão*: $cc\n📆 *Validade*: $mes/$ano\n🔐 *Cvv*: $cvv\n\n🏳 *Bandeira*: $bandeira\n💠 *Nível*: $nivel\n⚜ *Tipo*: $tipo\n🏛 *Banco*: $banco\n🌍 *Pais*: $pais\n\n🚀 DADOS AUXILIAR:\n*Nome:* $nome\n*Cpf:* $cpf\n\n💸 *Valor: R$ $preco*\n💰 *Novo Saldo: R$ $newSaldo*\n\n⏰ *Tempo para Reembolso*: ". date("d/m/Y")." ". date("H:$i:s")."\n\n✅ CC APROVADA NO CHK, STATUS: 00 - success";

    $chat_id = $ctx->getEffectiveChat()->getId();
     $message_id = $ctx->getUpdate()->getCallbackQuery()->getMessage()->getMessageId();
     $cc = $ccs['cc'];
  	$stmt = $pdo->prepare("DELETE FROM ccs WHERE cc = :cc");
   $stmt->bindParam(':cc', $cc, \PDO::PARAM_STR);
   $stmt->execute();
   
   
    $ctx->editMessageText($txt, [
        "chat_id" => $chat_id,
        "message_id" => $message_id, 
        "parse_mode" => "Markdown"
    ]);
  
  $nomecpf = "$nome\n$cpf";
    
   $stmt = $pdo->prepare("INSERT INTO hist_ccs (user_id, preco, nomecpf, level, lista, hour) VALUES (:user_id, :preco, :nomecpf, :level, :lista, :hour)");
   $stmt->bindParam(':user_id', $chat_id, \PDO::PARAM_STR);
   $stmt->bindParam(':preco', $preco, \PDO::PARAM_STR);
   $stmt->bindParam(':nomecpf', $nomecpf, \PDO::PARAM_STR);
   $stmt->bindParam(':level', $nivel, \PDO::PARAM_STR);
   $stmt->bindParam(':lista', $lista, \PDO::PARAM_STR);
   $stmt->bindParam(':hour', date("Y-m-d"), \PDO::PARAM_STR);
   $stmt->execute();
  
    
    $this->NotificarVendaCcs($ctx, $chat_id, $preco, $banco, $nivel);
    
    
    
    
      return true;
      
     }else{
     	$chat_id = $ctx->getEffectiveChat()->getId();
     $message_id = $ctx->getUpdate()->getCallbackQuery()->getMessage()->getMessageId();
     $cc = $ccs['cc'];
  	$stmt = $pdo->prepare("DELETE FROM ccs WHERE cc = :cc");
   $stmt->bindParam(':cc', $cc, \PDO::PARAM_STR);
   $stmt->execute();
   
   echo "deletae: $cc";
      $txt = "*❌ OPS ESTA CC ESTAVA DIE TENTE A PRÓXIMA*";
    $ctx->editMessageText($txt, [
        "chat_id" => $chat_id,
        "message_id" => $message_id, 
        "parse_mode" => "Markdown"
    ]);
    return true;
      
        }       
    }

    private function NotificarVendaCcs(Context $ctx, $chat_id, $preco, $banco, $nivel): void {
        $txt = "✅ NOVA CC VENDIDA COM SUCESSO\n\nBANCO: $banco\nNIVEL: $nivel\nVALOR: $preco\n\nID DO COMPRADOR: $chat_id\n\n🏆 STORE NÚMERO 1⁰ EM VENDAS!!!";

        $chat_msg = $_ENV["CHAT_NOTF"] ?? ''; 
        $ctx->sendMessage($txt, [
            "chat_id" => $chat_msg,
            "parse_mode" => "Markdown",
            "disable_web_page_preview" => true
        ]);
    }

    private function debitarSaldo($preco, $chat_id) {
    $pdo1 = Conn::get();

    $stmt = $pdo1->prepare("SELECT saldo FROM usuario_info WHERE chat_id = :chat_id");
    $stmt->bindParam(":chat_id", $chat_id, \PDO::PARAM_INT);
    $stmt->execute();
    $fetch = $stmt->fetch();
    $current_balance = $fetch['saldo'];

    $new_balance = $current_balance - $preco;

    $stmt_update = $pdo1->prepare("UPDATE usuario_info SET saldo = :saldo WHERE chat_id = :chat_id");
    $stmt_update->bindParam(':saldo', $new_balance, \PDO::PARAM_INT);
    $stmt_update->bindParam(':chat_id', $chat_id, \PDO::PARAM_INT);
    
    return $stmt_update->execute(); // Retorna true se a atualização for bem-sucedida
}
}