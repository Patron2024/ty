<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;
use App\Db\Conn;
use \PDO;

class Getpix {
    public bool $prt = false;

    public function handler(Context $ctx) {
        $admin = $_ENV["ADMIN"] ?? ''; // Certifique-se de que a vari�vel de ambiente 'ADMIN' est� configurada 
        $chat_id = $ctx->getEffectiveChat()->getId();

        if ($chat_id == $admin) {
            $pago = 0;
            $pendente = 0;
            $expirado = 0;

            $pagoH = 0;
            $pendenteH = 0;
            $expiradoH = 0;

            $data = date("d/m/Y");

            $banco = "MercadoPago";
            $pdo = Conn::get(); // Conectar ao banco de dados

            $stmt = $pdo->prepare("SELECT * FROM dados_pix WHERE banco = :banco");
            $stmt->bindParam(":banco", $banco, \PDO::PARAM_STR);
            $stmt->execute();

            $fetch = $stmt->fetch();
            $token = $fetch['token'] ?? '';

            $saldo = 0;
            $saldoH = 0;

            // Atualizando o status de cada venda
            $stmtpix = $pdo->prepare("SELECT * FROM pix");
            $stmtpix->execute();

            $multiCurl = curl_multi_init();
            $handles = [];

            while ($row = $stmtpix->fetch()) {
                $curl = curl_init();
                curl_setopt_array($curl, [
                    CURLOPT_URL => "https://pladixoficial.com.br/mercadoPago/checkPix.php?accessToken={$token}&payment_id={$row['id_pix']}",
                    CURLOPT_RETURNTRANSFER => true,
                ]);

                curl_multi_add_handle($multiCurl, $curl);
                $handles[] = $curl;
            }

            do {
                curl_multi_exec($multiCurl, $running);
                curl_multi_select($multiCurl);
            } while ($running > 0);

            foreach ($handles as $handle) {
                $exec = curl_multi_getcontent($handle);
                $exec = json_decode($exec, true);

                $message = $exec["message"];

                if ($message == "Pago") {
                    $pago++;
                } else if ($message == "Pagamento Pendente") {
                    $pendente++;
                } else {
                    $expirado++;
                }
            }

            curl_multi_close($multiCurl);

            $txt = " *Dashboard de Pagamentos*\n\n";
            $txt .= " *Status de cada pagamento*\n\n";
            $txt .= "*Total*\n";
            $txt .= "- Pagos: {$pago}\n";
            $txt .= "- Pendentes: {$pendente}\n";
            $txt .= "- Expirados: {$expirado}\n";
            $txt .= "- Total de Ganhos: R$ {$saldo}\n\n";
            $txt .= "*Hoje ({$data})*\n";
            $txt .= "- Pagos: {$pagoH}\n";
            $txt .= "- Pendentes: {$pendenteH}\n";
            $txt .= "- Expirados: {$expiradoH}\n";
            $txt .= "- Ganhos Hoje: R$ {$saldoH}\n\n";

            $button[] = ["text" => " VOLTA",
            "callback_data" => "admin"];
        
        $menu["inline_keyboard"] = array_chunk($button, 2);

        $ctx->editMessageText($txt, [
            "reply_markup" => $menu,
        ]);
        
        }
    }
}