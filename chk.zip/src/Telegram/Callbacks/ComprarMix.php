<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;
use App\Db\Conn;
use \PDO;

class Comprarmix
{
    public bool $prt = true;

    public function handler(Context $ctx) {
    // Obtemos o parâmetro da callback query
    $parameter = $ctx->getCallbackQuery()->getData();
    $param_parts = explode(" ", $parameter);
    
        if (count($param_parts) < 3) {
        $ctx->sendMessage("Formato de parâmetro incorreto.");
        return false;
    }
    
    $quantidade = intval($param_parts[1]); 
    $preco = intval($param_parts[2]); 
    
    
        $pdo = Conn::get();
        $chat_id = $ctx->getEffectiveChat()->getId();
        
        $stmt = $pdo->prepare("SELECT * FROM usuario_info WHERE chat_id = :chat_id"); 
        $stmt->bindParam(":chat_id", $chat_id, \PDO::PARAM_INT); 
        $stmt->execute(); 
        $fetchuser = $stmt->fetch(); 

        if ($fetchuser && $fetchuser['banido'] === 'true') {
            echo "Usuário bloqueado, retornando ao menu";
            $ctx->sendMessage([
                'chat_id' => $chat_id,
                'text' => "❌ VC TA BANIDO CONTATE NOSSO SUPORTE"
            ]);
            return false;
        }

        $stmt = $pdo->prepare("SELECT * FROM mix");
        $stmt->execute();
        $mixagens = $stmt->fetchAll();

     
        $saldo = $fetchuser['saldo'];
        $newSaldo = $saldo - $preco;

        if ($preco > $saldo || $newSaldo < 0) {
            $txt = "💰 | Saldo Insuficiente";
            $ctx->answerCallbackQuery($txt, true);
            return false;
        }

        foreach ($mixagens as $mixagem) {
            if ($mixagem['quantidade'] == $quantidade) {
                $mixs = $mixagem['mix'];
                $quantidade = $mixagem['quantidade'];
                $valor = $mixagem['valor'];
                $id = $mixagem['id'];
                
                $stmtDelete = $pdo->prepare("DELETE FROM mix WHERE id = :id"); 
                $stmtDelete->bindParam(':id', $id, \PDO::PARAM_INT); 
                $stmtDelete->execute();

                $this->debitarmix($preco, $chat_id, $pdo);

                $button[] = ['text' => "🔄 START", 'callback_data' => "start"];
                $menu['inline_keyboard'] = array_chunk($button, 1);
                $txt = "✅ COMPRA DE MIX EFETUADA\n\nMIX:\n$mixs\n\nQUANTIDADE: $quantidade\nVALOR: $valor";

                $message_id = $ctx->getCallbackQuery()->getMessage()->getMessageId();

                $ctx->editMessageText($txt, [
                    "chat_id" => $chat_id,
                    "message_id" => $message_id,
                    "reply_markup" => json_encode($menu),
                    "parse_mode" => 'Markdown'
                ]);
            }
        }
        
        return true;
    }

    private function debitarmix($preco, $chat_id, $pdo)
    {
        $stmt = $pdo->prepare("SELECT * FROM usuario_info WHERE chat_id = :chat_id");
        $stmt->bindParam(":chat_id", $chat_id, \PDO::PARAM_INT);
        $stmt->execute();

        $fetchuser = $stmt->fetch();
        $novoSaldo = $fetchuser['saldo'] - $preco;

        $stmt_update = $pdo->prepare("UPDATE usuario_info SET saldo = :saldo WHERE chat_id = :chat_id");
        $stmt_update->bindParam(':saldo', $novoSaldo, \PDO::PARAM_INT);
        $stmt_update->bindParam(':chat_id', $chat_id, \PDO::PARAM_INT);

        return $stmt_update->execute();
    }
}