<?php

namespace App\Telegram\Callbacks;

use App\Db\Conn;
use Zanzara\Context;

class Histccs
{
    public function handler(Context $ctx) {
        $pdo = Conn::get();

        $user_id = $ctx->getEffectiveChat()->getId();

        // Consulta SQL para obter o histórico de cartões de crédito para o usuário específico
        $stmt = $pdo->prepare("SELECT * FROM hist_ccs WHERE user_id = :user_id");
        $stmt->bindParam(":user_id", $user_id, \PDO::PARAM_STR);
        $stmt->execute();
        $historico = $stmt->fetchAll();

        $txt = "ℹ️ HISTORICO DE CCS ABAIXO:\n\n";

        // Construir a mensagem com base no histórico retornado do banco de dados
        foreach ($historico as $cc) {
            $txt .= "{$cc['cc']}\nPreco: {$cc['preco']}\nLista: {$cc['lista']}\nNome/CPF: {$cc['nomecpf']}\nNivel: {$cc['level']}\nHora: {$cc['hour']}\n---------------------------------------------------------\n";
        }

        

        $button[] = ["text" => "🔙 VOLTA",
            "callback_data" => "infov2"];

        $menu["inline_keyboard"] = array_chunk($button, 1);

        $ctx->editMessageText($txt, [
            "reply_markup" => $menu,
        ]);
    }
}