<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;
use App\Db\Conn;
use \PDO;

class Getgates {
    public bool $prt = false;

    public function handler(Context $ctx) {
        $admin = $_ENV["ADMIN"] ?? ''; // Certifique-se de que a variável de ambiente 'ADMIN' está configurada 
        $chat_id = $ctx->getEffectiveChat()->getId();
     $message_id = $ctx->getUpdate()->getCallbackQuery()->getMessage()->getMessageId();
        
        if ($chat_id == $admin) {
            $pdo = Conn::get();

            
                $stmt = $pdo->prepare("SELECT * FROM gates");
                $stmt->execute();
                
                $gates = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if ($gates) {
                    $txt = "Informações da tabela gates:\n";
                    foreach ($gates as $gate) {
                        $txt .= "ID: " . $gate['id'] . "\n";
                        $txt .= "Link: " . $gate['link'] . "\n";
                        $txt .= "Aprovada: " . $gate['aprovada'] . "\n";
                        $txt .= "Reprovada: " . $gate['reprovada'] . "\n\n";
                    }
                } else {
                    $txt = "Não há informações na tabela gates.";
                }

                $button[] = ["text" => "🔙 VOLTA",
            "callback_data" => "admin"];
        
        $menu["inline_keyboard"] = array_chunk($button, 2);

        $ctx->editMessageText($txt, [
            "reply_markup" => $menu,
        ]);
    
            
        }
    }
}