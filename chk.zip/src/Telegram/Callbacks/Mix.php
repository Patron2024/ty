<?php

namespace App\Telegram\Callbacks;

use App\Db\Conn;
use Zanzara\Context;

class Mix
{
	public bool $prt = true;
	
    public function handler(Context $ctx)
    {
        $pdo = Conn::get();

        $stmt = $pdo->prepare("SELECT * FROM mix");
        $stmt->execute();
        $mixagens = $stmt->fetchAll();
        
        if (empty($mixagens)) {
    $txt = "⚠️ | Base está sem mix!";
    $options = ["text" => $txt, "show_alert" => true]; 
    $ctx->answerCallbackQuery($options);
    return;
}

        $txt = "✅ MENU DE COMPRAR MIX:\n\n QUANTIDADE - VALOR";

        if ($mixagens) {
            $button = [];
            foreach ($mixagens as $index => $mixagem) {
                $mix = explode("\n", $mixagem['mix']);
                $quantidade = $mixagem['quantidade'];
                $valor = $mixagem['valor'];

                $button[] = ['text' => "🔥 $quantidade - $$valor", 'callback_data' => "ComprarMix $quantidade $valor"];
            }

            $button[] = ['text' => "↩️ VOLTA", 'callback_data' => "menu"];
            $menu['inline_keyboard'] = array_chunk($button, 1);

            $chat_id = $ctx->getEffectiveChat()->getId();
            $message_id = $ctx->getCallbackQuery()->getMessage()->getMessageId();

            $ctx->editMessageText($txt, [
                "chat_id" => $chat_id,
                "message_id" => $message_id,
                "reply_markup" => json_encode($menu),
                "parse_mode" => 'Markdown'
            ]);
        }
    }
}