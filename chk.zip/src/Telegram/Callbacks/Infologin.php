<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;
use App\Db\Conn;
use \PDO;

class InfoLogin {
    public bool $prt = false;

    public function handler(Context $ctx) {
        $pdo = Conn::get();
        
        $stmt = $pdo->prepare("SELECT DISTINCT tipo FROM login");
        $stmt->execute();
        $tipos = $stmt->fetchAll();
        
        if (empty($tipos)) {
            $txt = "⚠️ | Base está sem logins disponíveis!";
            $options = ["text" => $txt, "show_alert" => true]; 
            $ctx->answerCallbackQuery($options);
            return;
        }

        $buttons = [];
        $levels = [];

        foreach ($tipos as $tipoData) {
            $tipo = $tipoData['tipo'];

            $stmt = $pdo->prepare("SELECT * FROM preco WHERE nivel = :nivel");
            $stmt->bindParam(":nivel", $tipo, PDO::PARAM_STR);
            $stmt->execute();
            $fetchpreco = $stmt->fetch();
            
            $price = (!empty($fetchpreco['valor']) ? $fetchpreco['valor'] : 7);
            $levels[$tipo] = $price;
        }

        $buttons = [];
        $lvl = '';

        foreach ($levels as $nivel => $price) {
            $lvl .= "$nivel | (R$ $price)\n"; // Adiciona tipo e preço ao texto
            $buttons[] = ['text' => "$nivel | (R$ $price)", 'callback_data' => "chklog $nivel $price"];
        }
         $button[] = ['text'=>"", 'callback_data'=>"null"];
         
        $buttons[] = ['text' => '↩️ VOLTAR', 'callback_data' => 'menu'];

        $txt = "✨ *Escolha um login para compra!!!*\n\n$lvl"; // Adiciona todos os tipos e preços ao texto

        $menu['inline_keyboard'] = array_chunk($buttons, 2);
        
        $chat_id = $ctx->getEffectiveChat()->getId();
        $message_id = $ctx->getCallbackQuery()->getMessage()->getMessageId();
        
        $ctx->editMessageText($txt, [
            "chat_id" => $chat_id,
            "message_id" => $message_id,
            "reply_markup" => $menu,
            "parse_mode" => 'Markdown'
        ]);
    }
}