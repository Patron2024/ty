<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;

class Pesquisa
{
    public bool $prt = false;

    public function handler(Context $ctx) {
        $nome = $ctx->getEffectiveUser()->getFirstName();
        $txt = "🔎 MENU DE PESQUISA CC ESPECÍFICA

/banco (busca banco específico)
/bin (busca bin específica)

⚠️ DIGITE O NOME DO BANCO COMPLETO PARA ENCONTRAR!!";

        
            $button[] = ["text" => "🔙 VOLTA",
            "callback_data" => "menu"];
        
        $menu["inline_keyboard"] = array_chunk($button, 2);

        $ctx->editMessageText($txt, [
            "reply_markup" => $menu,
        ]);
    }
}