<?php

namespace App\Telegram\Callbacks;

use Zanzara\Context;
use \PDO;
use App\Db\Conn;
use Zanzara\Telegram\Type\BotCommand;

class Infov2 {
    public bool $prt = false;

    public function handler(Context $ctx) {
        $id = $ctx->getEffectiveUser()->getId();
        $pdo = Conn::get();

        // Obter o username do BOT
        $botUsername = "t.me/seu_bot"; // Substitua 'seu_bot' pelo username do seu BOT no Telegram

        $stmt = $pdo->prepare("SELECT * FROM usuario_info WHERE chat_id = :chat_id");
        $stmt->bindParam(":chat_id", $id, PDO::PARAM_INT);
        $stmt->execute();

        $fetch = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($fetch)) {
        	
            $banidoStatus = $fetch[0]['adm'] ? 'Sim' : 'Nao'; // Corrigido de 'Nao' para 'N�o'

            $txt = "Informacoes do Usuario:\n\n" .
                   "Nome: " . $fetch[0]['nome'] . "\n" .
                   "Usuario: " . $fetch[0]['usuario'] . "\n" .
                   "Saldo: " . $fetch[0]['saldo'] . "\n" .
                   "Pontos: " . $fetch[0]['pontos'] . "\n" .
                   "Adm: " . $banidoStatus . "\n" .
                   "Cadastrado em: " . $fetch[0]['cadastrado'] . "\n" .
                   "Ccs: " . $fetch[0]['ccs'] . "\n" .
                   "Mix: " . $fetch[0]['mix'] . "\n" .
                   "Recargas Manual: " . $fetch[0]['recarga_manual'] . "\n" .
                   "Recargas Pix: " . $fetch[0]['recarga_pix'] . "\n" .
                   "Gifts: " . $fetch[0]['gifts'] . "\n\n" .
                   "Link de Referencia: https://t.me/PaivaStore_Bot?start=" . $id; // Adiciona o link de refer�ncia com o username do BOT

        } else {
            $txt = "Usu�rio nao encontrado."; // Corrigido de 'nao' para 'n�o'
        }

        $button[] = ["text" => "VOLTA", "callback_data" => "start"];
        $button[] = ["text" => "HISTORICO CCS", "callback_data" => "histccs"]; // Corrigido de 'HISTORICO CCS' para 'HIST�RICO CCS'
        $button[] = ["text" => "TROCAR PONTOS", "callback_data" => "trocarpontos"];

        $menu["inline_keyboard"] = array_chunk($button, 1);

        $ctx->editMessageText($txt, [
            "reply_markup" => $menu,
            'parse_mode' => 'HTML',
        ]);
    }
}

?>