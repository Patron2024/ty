<?php

namespace App\Telegram;

use Zanzara\Context;
use App\Controller\Controller;

class Command
{
    protected ?string $command;
    protected ?string $parameter;
    private array $prefix = [
        "/",
        "*",
        "!"
    ];

    public function __construct(?string $txt) {
        if (is_string($txt)) {
            $data = @ explode(" ", $txt);
            if (count($data) < 2) {
                $comando = @ strtolower(trim(str_ireplace($this->prefix, "", $data[0])));
                $this->command = $comando;
                $this->parameter = '';
            } else {
                $comando = @ strtolower(trim(str_ireplace($this->prefix, "", $data[0])));
                $this->command = $comando;
                $prt = @ str_ireplace($comando . " ", "", implode(" ", $data));
                $this->parameter = @ str_ireplace($this->prefix, "", $prt);
            }
        }
    }

    public function handler(Context $ctx): void
    {
        $use = "App\Telegram\Commands\\" . $this->getCommand();
        if (class_exists($use)) {
            $id = $ctx->getEffectiveUser()->getId();
            $nome = $ctx->getEffectiveUser()->getFirstName();
            $username = '@' . $ctx->getEffectiveUser()->getUsername();
            
            $scan = Controller::scan($id, $nome, $username);

            if ($scan["status"]) {
                $class = new $use();
                if (!$class->prt) {
                    $class->handler($ctx);
                } else {
                    $class->handler($ctx, $this->getParameter());
                }
            } else {
                $ctx->sendMessage("*" . $scan[0]["message"] . "*", [
                    "reply_to_message_id" => $ctx->getMessage()->getId(),
                ]);
            }
        }
    }

    private function getCommand(): ?string
    {
        return $this->command;
    }

    private function getParameter(): ?string
    {
        return $this->parameter;
    }
}