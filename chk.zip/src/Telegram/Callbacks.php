<?php

namespace App\Telegram;

use Zanzara\Context;
use App\Controller\Controller;

class Callbacks
{
    protected ?string $data;
    protected ?string $parameter;

    public function __construct(?string $data) {
        if (is_string($data)) {
            $data = @ explode(" ", $data);
            $comando = @ ucfirst(trim($data[0]));
            $this->data = $comando;
            $this->parameter = @ str_ireplace($comando, "", implode(" ", $data));
        }
    }

    public function handler(Context $ctx): void
    {
        $use = "App\Telegram\Callbacks\\" . $this->getCommand();
        if (class_exists($use)) {
            $id = $ctx->getEffectiveUser()->getId();
            $nome = $ctx->getEffectiveUser()->getFirstName();
            $username = '@' . $ctx->getEffectiveUser()->getUsername();
            
            $scan = Controller::scan($id, $nome, $username);

            if ($scan["status"]) {
                $class = new $use();
                if (!$class->prt) {
                    $class->handler($ctx);
                } else {
                    $class->handler($ctx, $this->getParameter());
                }
            } else {
                $ctx->editMessageText("*" . $scan[0]["message"] . "*");
            }
        } else {
            $ctx->answerCallbackQuery([
                "show_alert" => true,
                "text" => "⚠️ Em desenvolvimento!",
            ]);
        }
    }

    private function getCommand(): ?string
    {
        return $this->data;
    }

    private function getParameter(): ?string
    {
        return $this->parameter;
    }
}