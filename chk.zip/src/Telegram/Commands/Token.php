<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use App\Db\Conn;
use PDO; // Adicionar a referência absoluta para a classe PDO

class Token {
    public bool $prt = false;

    public function handler(Context $ctx) {
        $message = $ctx->getMessage()->getText();
        $chat_id = $ctx->getEffectiveChat()->getId();
        $parts = explode(' ', $message);
        $pdo = Conn::get();
        
        if(isset($parts[0]) && $parts[0] == '/token' && isset($parts[1])) {      
            $token = $parts[1];
             
        $id = "MercadoPago";
        $stmt = $pdo->prepare("UPDATE dados_pix SET token = :gate WHERE banco = :id");
        $stmt->bindParam(":gate", $token, PDO::PARAM_STR);
        $stmt->bindParam(":id", $id, PDO::PARAM_STR);
        $stmt->execute();
        
        $txt = "Token Mercado Pago Atualizado Com sucesso";
        
        $ctx->sendMessage($txt, [
                 "reply_to_message_id" => $ctx->getMessage()->getMessageId(),
                 "parse_mode" => 'Markdown'
                ]);
              
            
          }
        }
      }