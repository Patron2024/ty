<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use PDO;
use App\Db\Conn;

class Mix {
    public bool $prt = true;

    public function handler(Context $ctx) {
        $admin = $_ENV["ADMIN"] ?? '';
        $chat_id = $ctx->getUpdate()->getMessage()->getChat()->getId();
        $texto = $ctx->getUpdate()->getMessage()->getText();
        $message_id = $ctx->getUpdate()->getMessage()->getMessageId();
        $id = $ctx->getUpdate()->getMessage()->getFrom()->getId();

        // Obter a conexão PDO
        $pdo = Conn::get();
        if (strpos($texto, "/mix") === 0) {
          $ccmix = trim(substr($texto, 5));

            // Inicializa a contagem de linhas, adições e erros
            $total = 0;
            $add = 0;
            $erros = 0;
        

            // Verifica se $pdo não é nulo antes de usá-lo
            if ($pdo !== null) {
         
            
                // Lê o conteúdo do banco de dados para obter a mistura atual
                $stmt = $pdo->prepare("SELECT * FROM mix");
                $stmt->execute();
                $mix = $stmt->fetchAll(PDO::FETCH_ASSOC);


                $mix_temp = explode("===", str_replace(array(":", ";", ",", "=>", "-", " ", "|||"), "===", str_replace(" ", "/", trim($ccmix))));

                $ccsmix = $mix_temp[0] ?? '';
                $quantidade = $mix_temp[1] ?? '';
                $valor = $mix_temp[2] ?? '';
                $id = rand(99999, 10000);

                // Verifica se algum dos campos está vazio e incrementa a contagem de erros corretamente
                if (empty($ccsmix) || empty($quantidade) || empty($valor)) {
                    $erros++;
                } else {
                    $stmt = $pdo->prepare("INSERT INTO mix (id, mix, quantidade, valor) VALUES (:id, :mix, :quantidade, :valor)");
                    $stmt->bindParam(":id", $id);
                    $stmt->bindParam(":mix", $ccsmix);
                    $stmt->bindParam(":quantidade", $quantidade);
                    $stmt->bindParam(":valor", $valor);
                    $stmt->execute();

                    // Aumenta o contador de adições bem sucedidas
                    $add++;
                }

                // Imprime a mensagem final com o total de adições bem sucedidas e erros encontrados
                if ($add > 0) {
                    $mensagem_final = "✅ MIX ADD COM SUCESSO";
                } else {
                    $mensagem_final = "❌ ERRO AO ADICIONAR MIX";
                }

                $ctx->sendMessage($mensagem_final, ["chat_id" => $chat_id, "reply_to_message_id" => $message_id, "parse_mode" => 'Markdown']);
            }
            else {
                // Tratar caso a conexão PDO seja nula
                $ctx->sendMessage("❌ Erro na conexão com o banco de dados.", ["chat_id" => $chat_id]);
            }
        }
    }

}

?>