<?php

namespace App\Telegram\Commands;

use App\Db\Conn;
use Zanzara\Context;

class Start
{
    public bool $prt = false;

    public function handler(Context $ctx) {
    	$pdo = Conn::get();
    
$user_id = $ctx->getEffectiveUser()->getId(); 
        $stmrt = $pdo->prepare("SELECT * FROM usuario_info WHERE chat_id = :chat_id");
$stmrt->bindParam(":chat_id", $user_id, \PDO::PARAM_STR); // Substitua $configValue pelo valor desejado
$stmrt->execute();
$fetch4 = $stmrt->fetchAll(\PDO::FETCH_ASSOC);


     $configValue = "config";
        $stmtt = $pdo->prepare("SELECT * FROM config WHERE id = :chat_id");
$stmtt->bindParam(":chat_id", $configValue, \PDO::PARAM_STR); // Substitua $configValue pelo valor desejado
$stmtt->execute();
$fetch2 = $stmtt->fetchAll(\PDO::FETCH_ASSOC);

if (!empty($fetch4[0]) && $fetch4[0]["banido"] === 'true') {
      	$txt = "❌ VC FOI BANIDO POR UM ADM!!";
      	$ctx->sendMessage($txt);
        return true;
      }

      if (!empty($fetch2[0]) && $fetch2[0]["manutencao"] === 'true') {
      	$txt = "❌ ESTAMOS EM MANUTENÇÃO, VOLTE DAQUI UNS MINUTOS";
      	$ctx->sendMessage($txt);
        return true;
      }
     $stmut = $pdo->prepare("SELECT * FROM textos WHERE tipo = 'start'");
    $stmut->execute();
    $fetch3 = $stmut->fetchAll(\PDO::FETCH_ASSOC);
     
     $txtp = $fetch3[0]["texto"];
     
     $message_id = $ctx->getMessage()->getMessageId();
        $nome = $ctx->getEffectiveUser()->getFirstName();
        $user_id = $ctx->getEffectiveUser()->getId(); 
     
     $txtp = str_replace("{nome}", $nome, $txtp);
     $txtp = str_replace("{chat_id}", $user_id, $txtp);
     
        $message_id = $ctx->getMessage()->getMessageId();
        $nome = $ctx->getEffectiveUser()->getFirstName();
        $user_id = $ctx->getEffectiveUser()->getId(); // Obtém o ID do usuário que enviou a mensagem
        $txt = $ctx->getMessage()->getText();

        $txt2 = "🚀 BEM VINDO $nome À MELHOR BASE DE CCS

[REFERÊNCIAS](t.me/PaivaStore)
[SUPORTE](t.me/PaivaCcs)

✅ GARANTIMOS LIVE
❌ NÃO GARANTIMOS SALDO

✅ PIX AUTOMÁTICO 
Exemplo: /pix 10
✅ CHECKER ONLINE
✅ TROCAS EM ATE 10 MINUTOS";        

        $button[] = ["text" => "👤 INFO",
            "callback_data" => "infov2"];
        $button[] = ["text" => "⚙️ DEV",
            "callback_data" => "dev"];
        $button[] = ["text" => "ℹ️ MENU",
            "callback_data" => "menu"];

        $menu["inline_keyboard"] = array_chunk($button, 1);

        // Verifica se há um ID após o comando /start na mensagem
        $parts = explode(' ', $txt);
        if (count($parts) > 1) {
            $referal_id = $parts[1]; // Obtém o possível ID do referal após o comando /start
       echo "ID: $referal_id TXT= $txt";
  
            

            // Verifica se o ID do referal do usuário atual está em branco
            $stmt = $pdo->prepare("SELECT referal FROM usuario_info WHERE chat_id = :user_id");
            $stmt->bindParam(":user_id", $user_id, \PDO::PARAM_INT);
            $stmt->execute();
            $referal_info = $stmt->fetch();

            if (empty($referal_info['referal'])) {
                // Atualizar o referal do usuário atual com o ID do referal após /start
                $referal_id = intval($referal_id); // Converte para inteiro
                $stmtUpdate = $pdo->prepare("UPDATE usuario_info SET referal = :referal_id WHERE chat_id = :user_id");
                $stmtUpdate->bindParam(":referal_id", $referal_id, \PDO::PARAM_INT);
                $stmtUpdate->bindParam(":user_id", $user_id, \PDO::PARAM_INT);
                $stmtUpdate->execute();

                // Atualizar os pontos do referal_id em +2
                $stmtUpdatePoints = $pdo->prepare("UPDATE usuario_info SET pontos = pontos + 2 WHERE chat_id = :referal_id");
                $stmtUpdatePoints->bindParam(":referal_id", $referal_id, \PDO::PARAM_INT);
                $stmtUpdatePoints->execute();

                // Enviar mensagem para o referal_id
                $ctx->sendMessage("NOVO USER SE CADASTROU COM TEU ID", ['chat_id' => $referal_id]);
            }
        }

        $ctx->sendMessage($txtp,
            [
                "reply_markup" => $menu,
                "reply_to_message_id" => $message_id,
            ]);
    }
}

?>