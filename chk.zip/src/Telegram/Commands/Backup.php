<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use CURLFile;
use PDO;
use App\Db\Conn;

class Backup {
    public bool $prt = true;

    public function handler(Context $ctx) {
        $admin = $_ENV["ADMIN"] ?? ''; // Certifique-se de que a variável de ambiente 'ADMIN' está configurada
        $chat_id = $ctx->getUpdate()->getMessage()->getChat()->getId();

        if ($chat_id == $admin) {
            $pdo = Conn::get();

            if ($pdo) {
                // Obtém o nome do banco de dados
                $dbName = $pdo->query("SELECT database()")->fetchColumn();

                // Obter todas as tabelas do banco de dados
                $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);

                if ($tables) {
                    // Inicializa o backup SQL
                    $backupData = "-- Database Backup By PatronDvs\n\n";
                    $backupData .= "-- Timestamp: " . date('Y-m-d H:i:s') . "\n\n";
                    

                    foreach ($tables as $table) {
                        $table = addslashes($table);

                        // Backup da estrutura da tabela
                        $tableStructure = $pdo->query("SHOW CREATE TABLE $table")->fetchColumn(1);
                        $backupData .= "$tableStructure;\n\n";

                        // Backup dos dados da tabela
                        $tableData = $pdo->query("SELECT * FROM $table")->fetchAll();
                        if ($tableData) {
                            $backupData .= "-- Início dos dados da tabela $table\n";
                            foreach ($tableData as $row) {
                                $row = array_map('addslashes', $row);
                                $backupData .= "INSERT INTO $table VALUES ('" . implode("', '", $row) . "');\n";
                            }
                            $backupData .= "-- Fim dos dados da tabela $table\n\n";
                        }
                    }

                    // Salvando o backup em um arquivo .sql
                    $backupFileName = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
                    file_put_contents($backupFileName, $backupData . PHP_EOL, FILE_APPEND);

                    // Enviar o arquivo de backup como documento
                    $token = $_ENV["BOT_TOKEN"] ?? '';
                    if (file_exists($backupFileName) && $token) {
                        $url = "https://api.telegram.org/bot{$token}/sendDocument";
      $post = array('chat_id' => $chat_id, 'caption' => "✅ OPA ADM, BACKUP DO SQL TA NA MÃO!!!", 'document' => new CURLFile(realpath($backupFileName)));
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
      curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type:multipart/form-data"));
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      $result = curl_exec($ch);
      // Finaliza e deleta o arquivo ZIP após o envio
      curl_close($ch);

                        // Deletar o arquivo após o envio
                        unlink($backupFileName);
                    } else {
                        $ctx->sendMessage("Falha ao criar o arquivo de backup ou o token do bot não está configurado.");
                    }
                } else {
                    $ctx->sendMessage("Não foram encontradas tabelas no banco de dados.");
                }
            } else {
                $ctx->sendMessage("Erro ao estabelecer conexão com o banco de dados.");
            }
        } else {
            $ctx->sendMessage('Você não tem permissão para realizar esta ação.');
        }
    }
}