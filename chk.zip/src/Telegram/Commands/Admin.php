<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use App\Db\Conn;
use PDO;

class Admin {
    public bool $prt = false;

    public function handler(Context $ctx) {
        $admin = $_ENV["ADMIN"] ?? ''; // Certifique-se de que a variável de ambiente 'ADMIN' está configurada 
        $chat_id = $ctx->getUpdate()->getMessage()->getChat()->getId(); 
        
        if ($chat_id == $admin) {
            $pdo = Conn::get();
            
           $txt = "menu admin abaixo";
            
         $buttons[] = ['text' => "LISTA GATES", 'callback_data' => "getgates"];
         $buttons[] = ['text' => "HISTÓRICO PIX", 'callback_data' => "getpix"];
         $buttons[] = ['text' => "RELATÓRIO", 'callback_data' => "GetSt"];
         $buttons[] = ['text' => "MANUTENÇÃO", 'callback_data' => "getmanu"];
         $buttons[] = ['text' => "SELECIONAR GATE", 'callback_data' => "selgate"];
         $buttons[] = ['text' => "BACKUP", 'callback_data' => "backup"];
            $menu['inline_keyboard'] = array_chunk($buttons, 1);

            $ctx->sendMessage($txt, [
                "reply_markup" => $menu,
                "reply_to_message_id" => $ctx->getMessage()->getMessageId(),
            ]);
            
         } else {
          $txt = "❌ OPPS VC NÃO É ADM";
            $ctx->sendMessage($txt, [
                "reply_to_message_id" => $ctx->getMessage()->getMessageId(),
            ]);
        
       }
     }
   }