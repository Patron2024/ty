<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use PDO;
use App\Db\Conn;

class Resgatar {
    public bool $prt = true;

    public function handler(Context $ctx) {
        $conf = [
            'user_bot' => 'nome_do_bot', // Defina aqui o nome do seu bot
        ];

        $admin = $_ENV["ADMIN"] ?? '';
        $chat_id = $ctx->getUpdate()->getMessage()->getChat()->getId();
        $texto = $ctx->getUpdate()->getMessage()->getText();
        
        $pdo = Conn::get(); 

        $gift = substr($texto, 10);
        
        echo "gift: $gift";

        $stmt = $pdo->prepare("SELECT * FROM gift WHERE gift = :gift AND resgate = '1'");
        $stmt->bindParam(":gift", $gift);
        $stmt->execute();
        $giftData = $stmt->fetch();

        if ($giftData) {
            $valor = $giftData['valor'];
            $nome = $ctx->getUpdate()->getMessage()->getFrom()->getFirstName();
            
            $stmt = $pdo->prepare("UPDATE gift SET resgate = '0', usuario_resgate = :usuario_resgate, data_resgate = :data_resgate, hora_resgate = :hora_resgate WHERE gift = :gift");
            $stmt->bindParam(":usuario_resgate", $nome);
            $stmt->bindParam(":data_resgate", date('d/m/Y'));
            $stmt->bindParam(":hora_resgate", date('H:i:s'));
            $stmt->bindParam(":gift", $gift);
            $stmt->execute();

            $id = $ctx->getUpdate()->getMessage()->getFrom()->getId();
            $stmt = $pdo->prepare("SELECT * FROM usuario_info WHERE chat_id = :id");
            $stmt->bindParam(":id", $chat_id);
            $stmt->execute();
            $usuario = $stmt->fetch();
            $valor += $usuario['saldo'];
            
            $stmt = $pdo->prepare("UPDATE usuario_info SET gifts = gifts + 1, saldo = :saldo WHERE chat_id = :id");
            $stmt->bindParam(":saldo", $valor);
            $stmt->bindParam(":id", $chat_id);         
            $stmt->execute();

            $txt2 = "*🎁 Gift foi resgatado!*\n- Você ganhou *R$ $valor*\n- Saldo Novo: *R$ $valor*";
            $buttons[] = ['text' => "MENU", 'callback_data' => "start"];
            $menu['inline_keyboard'] = array_chunk($buttons, 2);

            $ctx->sendMessage("$txt2", ["reply_to_message_id" => $message_id, "parse_mode" => 'Markdown', "reply_markup" => $menu]);

            // Chame a função 'notificarVendaGift' aqui passando os parâmetros necessários
            
        } else {
            $ctx->sendMessage("*Gift não existe ou já foi resgatado!*", ["reply_to_message_id" => $message_id, "parse_mode" => 'Markdown']);
        }
    }
}

?>