<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use App\Db\Conn;

class Preco {
    public function handler(Context $ctx) {
        $admin = $_ENV["ADMIN"] ?? '';
        $chat_id = $ctx->getUpdate()->getMessage()->getChat()->getId();

        if ($chat_id == $admin) {
            $pdo = Conn::get();
            $texto = $ctx->getMessage()->getText();
            $ccText = trim(substr($texto, strlen('/preco')));
            $ccList = explode("\n", $ccText);
            $respostas = [];

            foreach ($ccList as $value) {
                $ccData = explode("|", trim($value));
                if (count($ccData) !== 2) {
                    $respostas[] = "Formato incorreto. Use /preco NIVEL|PRECO";
                    continue;
                }

                $nivel = $ccData[0] ?? '';
                $preco = $ccData[1] ?? '';

                if (!is_numeric($preco)) {
                    $respostas[] = "Preço inválido fornecido para o nível $nivel.";
                    continue;
                }

                $stmt = $pdo->prepare("SELECT * FROM preco WHERE nivel = :nivel");
                $stmt->bindParam(':nivel', $nivel);
                $stmt->execute();
                $result = $stmt->fetch();

                if ($result) {
                    $stmt = $pdo->prepare("UPDATE preco SET valor = :preco WHERE nivel = :nivel");
                    $stmt->bindParam(':preco', $preco);
                    $stmt->bindParam(':nivel', $nivel);
                    $stmt->execute();
                    $respostas[] = "Preço atualizado com sucesso para o nível $nivel: R$ $preco";
                } else {
                    $stmt = $pdo->prepare("INSERT INTO preco (nivel, valor) VALUES (:nivel, :preco)");
                    $stmt->bindParam(':nivel', $nivel);
                    $stmt->bindParam(':preco', $preco);
                    $stmt->execute();
                    $respostas[] = "Novo preço criado para o nível $nivel: R$ $preco";
                }
            }

            // Enviar uma resposta consolidada
            $mensagem_final = implode("\n", $respostas);
            $ctx->sendMessage($mensagem_final, ["reply_to_message_id" => $ctx->getMessage()->getMessageId()]);
        } else {
            $ctx->sendMessage("❌ Você não tem permissão para usar este comando.", ["reply_to_message_id" => $ctx->getMessage()->getMessageId()]);
        }
    }
}