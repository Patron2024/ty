<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use App\Db\Conn;
use PDO; // Adicionar a refer�ncia absoluta para a classe PDO

class Bin {
    public bool $prt = false;

    public function handler(Context $ctx) {
        $message = $ctx->getMessage()->getText();
        $chat_id = $ctx->getEffectiveChat()->getId();
        $parts = explode(' ', $message);
        $pdo = Conn::get();
        
        if(isset($parts[0]) && $parts[0] == '/bin' && isset($parts[1])) {      
            $bin = $parts[1];

            $stmt = $pdo->prepare("SELECT * FROM ccs WHERE bin = :bin LIMIT 1");
            $stmt->bindParam(":bin", $bin, PDO::PARAM_INT); // Corrigir refer�ncia para a classe PDO aqui
            $stmt->execute();

            $ccs = $stmt->fetch();

            if (empty($ccs)) {
                $txt = "Bin nao encontrada!";
                $ctx->sendMessage($txt, [
                    "reply_to_message_id" => $ctx->getMessage()->getMessageId(),
                ]);
                return;
            }

            $nivel = $ccs['nivel'];
            $bandeira = $ccs['bandeira'];
            $tipo = $ccs['tipo'];
            $banco = $ccs['banco'];
            $pais = $ccs['pais'];
            $cc = $ccs['cc'];

            $stmt = $pdo->prepare("SELECT * FROM preco WHERE nivel = :nivel"); 
            $stmt->bindParam(":nivel", $nivel, PDO::PARAM_STR); // Corrigir refer�ncia para a classe PDO aqui
            $stmt->execute();

            $preco = $stmt->fetch();
            $price = $preco['valor'];

            $txt = "BIN ENCONTRADA\n\nNIVEL: $nivel\nBANDEIRA: $bandeira\nTIPO: $tipo\nPAIS: $pais\nPRECO: $price\n\nCLIQUE NO BOTAO ABAIXO SOMENTE SE TIVER CERTEZA DA COMPRA!!!";

            $buttons[] = ['text' => "COMPRAR", 'callback_data' => "chkbin $cc $price"];
            $menu['inline_keyboard'] = array_chunk($buttons, 2);

            $ctx->sendMessage($txt, [
                "reply_markup" => $menu,
                "reply_to_message_id" => $ctx->getMessage()->getMessageId(),
            ]);
        }
    }  
}