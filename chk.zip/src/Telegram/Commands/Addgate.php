<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use App\Db\Conn;
use PDO;

class Addgate {
    public bool $prt = false;

    public function handler(Context $ctx) {
        $admin = $_ENV["ADMIN"] ?? ''; // Certifique-se de que a variável de ambiente 'ADMIN' está configurada 
        $chat_id = $ctx->getUpdate()->getMessage()->getChat()->getId(); 
        
        if ($chat_id == $admin) {
            $pdo = Conn::get();

            $message = $ctx->getMessage()->getText();
            
            if (strpos($message, '/addgate') === 0) {
                $data = explode("|", substr($message, 9)); // Divide a mensagem após o comando /addgate pela barra vertical |
                
                $id = $data[0] ?? '';
                $link = $data[1] ?? '';
                $aprovada = $data[2] ?? '';
                $reprovada = $data[3] ?? '';

                $stmt = $pdo->prepare("SELECT * FROM gates WHERE id = :id");
                $stmt->bindParam(":id", $id, PDO::PARAM_STR);
                $stmt->execute();

                $existing_gate = $stmt->fetch();

                if ($existing_gate) {
                    $stmt = $pdo->prepare("UPDATE gates SET link = :link, aprovada = :aprovada, reprovada = :reprovada WHERE id = :id");
                    $status = "Atualizadas";
                } else {
                    $stmt = $pdo->prepare("INSERT INTO gates (id, link, aprovada, reprovada) VALUES (:id, :link, :aprovada, :reprovada)");
                    $status = "Adicionadas";
                }

                $stmt->bindParam(":id", $id, PDO::PARAM_STR);
                $stmt->bindParam(":link", $link, PDO::PARAM_STR);
                $stmt->bindParam(":aprovada", $aprovada, PDO::PARAM_STR);
                $stmt->bindParam(":reprovada", $reprovada, PDO::PARAM_STR);
                $stmt->execute();

                $txt = "Informações $status para o ID: $id na tabela gates.";
                $ctx->sendMessage($txt);
            }
        }
    }
}