<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use PDO;
use App\Db\Conn;

class Gift {
    public bool $prt = true;

    public function handler(Context $ctx) {
        $admin = $_ENV["ADMIN"] ?? '';
        $chat_id = $ctx->getUpdate()->getMessage()->getChat()->getId();

        if ($chat_id == $admin) {
            $pdo = Conn::get(); 

            $texto = $ctx->getUpdate()->getMessage()->getText();
            $valor = preg_replace('/[^0-9]/', '', substr($texto, 6));

            if (empty($valor) || $valor <= 0) {
                $valor = 1;
            }
       
            $cod1 = rand(99999, 10000);
            $cod2 = rand(99999, 10000);
            $cod3 = rand(99999, 10000);
       
            $gift = "GIFT-$cod2-$cod3";
            
            $resgate = true;

            $stmt = $pdo->prepare("INSERT INTO gift (gift, valor, resgate, usuario_resgate, data_resgate, hora_resgate) VALUES (:gift, :valor, :resgate, NULL, NULL, NULL)");
            $stmt->bindParam(":gift", $gift);
            $stmt->bindParam(":valor", $valor);
            $stmt->bindParam(":resgate", $resgate, PDO::PARAM_BOOL); // Utilize PARAM_BOOL para bind de valores booleanos
            $stmt->execute();

            if ($stmt) {
                $txt2 = "*🎁 GIFT GERADO*\n💰 *Valor:* R$$valor,00\n🪪 *Gift*: /resgatar $gift";
            } else {
                $txt2 = "*Falha ao gerar gift, contate o dev*";
            }
            
            $ctx->sendMessage("$txt2", ["reply_to_message_id" => $message_id, "parse_mode" => 'Markdown']);
        }
    }
}

?>