<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use App\Db\Conn;

class Login {
    public bool $prt = true;

    public function handler(Context $ctx) {
        $admin = $_ENV["ADMIN"] ?? ''; // Certifique-se de que a variável de ambiente 'ADMIN' está configurada
        $chat_id = $ctx->getUpdate()->getMessage()->getChat()->getId();

        if ($chat_id == $admin) {
            $pdo = Conn::get();
            $texto = $ctx->getMessage()->getText();
            $ccText = trim(substr($texto, 7));
            $ccList = explode("\n", $ccText);

            $ccs = []; // Inicializando o array $ccs

            $total = 0;
            $add = 0;
            $erros = 0;

            $mh = curl_multi_init();
            $handles = [];

            foreach ($ccList as $value) {
                $ccData = explode("|", str_replace(array(":", ";", ",", "=>", "-", " ", "|||"), "|", str_replace(" ", "/", trim($value))));
                $login = $ccData[0] ?? '';
                $senha = $ccData[1] ?? '';
                $cidade = $ccData[2] ?? '';
                $tipo = $ccData[3] ?? '';

                if (empty($login) || empty($senha) || empty($cidade) || empty($tipo)) {
                    $erros++;
                } elseif (isset($ccs[$login])) {
                    $erros++;
                } else {
                    $total++;

                    $stmt = $pdo->prepare("INSERT INTO login (login, senha, cidade, tipo) VALUES (:login, :senha, :cidade, :tipo)");
                    $stmt->bindParam(':login', $login);
                    $stmt->bindParam(':senha', $senha);
                    $stmt->bindParam(':cidade', $cidade);
                    $stmt->bindParam(':tipo', $tipo);
                
                    $stmt->execute();

                    $add++;
                }
            }

            $mensagem_final = "✅ TOTAL DE LINHAS LIDAS: $total\n🚀 TOTAL ADICIONADAS: $add\n❌ TOTAL DE ERROS: $erros";
            $message_id = $ctx->getMessage()->getMessageId();
            $ctx->sendMessage($mensagem_final, [
                "reply_to_message_id" => $message_id,
            ]);
        }
    }
}