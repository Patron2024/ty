<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use App\Db\Conn;

class Add {
    public bool $prt = true;

    public function handler(Context $ctx) {
        $admin = $_ENV["ADMIN"] ?? ''; // Certifique-se de que a variável de ambiente 'ADMIN' está configurada
        $chat_id = $ctx->getUpdate()->getMessage()->getChat()->getId();

        if ($chat_id == $admin) {
            $pdo = Conn::get();
            $texto = $ctx->getMessage()->getText();
            $ccText = trim(substr($texto, 5));
            $ccList = explode("\n", $ccText);

            $ccs = []; // Inicializando o array $ccs

            $total = 0;
            $add = 0;
            $erros = 0;

            $mh = curl_multi_init();
            $handles = [];

            foreach ($ccList as $value) {
                $ccData = explode("|", str_replace(array(":", ";", ",", "=>", "-", " ", "|||"), "|", str_replace(" ", "/", trim($value))));
                $cc = $ccData[0] ?? '';
                $mes = $ccData[1] ?? '';
                $ano = $ccData[2] ?? '';
                $cvv = $ccData[3] ?? '';

                if (empty($cc) || empty($mes) || empty($ano) || empty($cvv)) {
                    $erros++;
                } elseif (isset($ccs[$cc])) {
                    $erros++;
                } else {
                    $bin = substr($cc, 0, 6);
                    $ch = curl_init();
                    curl_setopt_array($ch, [
                        CURLOPT_URL => "https://bet.patronhost.online/bin.php?bin=$bin",
                        CURLOPT_RETURNTRANSFER => true,
                    ]);
                    curl_multi_add_handle($mh, $ch);
                    $handles[$cc] = $ch;
                }
                $total++;
            }

            $running = null;
            do {
                curl_multi_exec($mh, $running);
            } while ($running > 0);

            foreach ($handles as $cc => $ch) {
                $dados1 = curl_multi_getcontent($ch);
                $dados1 = json_decode($dados1, true);

                $level = $dados1["level"] ?? '';
                $banco = $dados1["banco"] ?? '';
                $tipo = $dados1["tipo"] ?? '';
                $bandeira = $dados1["bandeira"] ?? '';
                $pais = $dados1["pais"] ?? '';
                $bin2 = $dados1["bin"] ?? '';

                $lista = "$cc|$mes|$ano|$cvv";

                $stmt = $pdo->prepare("INSERT INTO ccs (cc, lista, nivel, bandeira, tipo, banco, pais, bin) VALUES (:cc, :lista, :nivel, :bandeira, :tipo, :banco, :pais, :bin)");
                $stmt->bindParam(':cc', $cc);
                $stmt->bindParam(':lista', $lista);
                $stmt->bindParam(':nivel', $level);
                $stmt->bindParam(':bandeira', $bandeira);
                $stmt->bindParam(':tipo', $tipo);
                $stmt->bindParam(':banco', $banco);
                $stmt->bindParam(':pais', $pais);
                $stmt->bindParam(':bin', $bin2);
                $stmt->execute();

                curl_multi_remove_handle($mh, $ch);
                $add++;
            }

            curl_multi_close($mh);

            $mensagem_final = "✅ TOTAL DE LINHAS LIDAS: $total\n🚀 TOTAL ADICIONADAS: $add\n❌ TOTAL DE ERROS: $erros";
            $message_id = $ctx->getMessage()->getMessageId();
            $ctx->sendMessage($mensagem_final, [
                "reply_to_message_id" => $message_id,
            ]);
        }
    }
}