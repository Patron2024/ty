<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use App\Db\Conn;
use \PDO; // Incluir a referência completa para a classe PDO

class Estoque {
    public function handler(Context $ctx) {
        $pdo = Conn::get();

        $stmt = $pdo->prepare("SELECT * FROM ccs");
        $stmt->execute();
        $ccs = $stmt->fetchAll();

        $levels = [];

        foreach ($ccs as $cc) {
            $nivel = $cc['nivel'];

            // Aumentar a contagem de consultas para esse nível
            if (array_key_exists($nivel, $levels)) {
                $levels[$nivel]++;
            } else {
                $levels[$nivel] = 1; // Iniciar a contagem para 1 se for o primeiro nível encontrado
            }
        }

        $lvl = '';

        foreach ($levels as $nivel => $count) {
            $lvl .= "$nivel ($count)\n";
        }

        $mensagem_final = "✅ Consultas por Nível:\n$lvl";

        $ctx->sendMessage($mensagem_final, ["reply_to_message_id" => $ctx->getMessage()->getMessageId()]);
    }
}