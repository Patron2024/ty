<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use App\Db\Conn;
use PDO; // Adicionar a referência absoluta para a classe PDO

class Banco {
    public bool $prt = false;

    public function handler(Context $ctx) {
        $message = $ctx->getMessage()->getText();
        $chat_id = $ctx->getEffectiveChat()->getId();
        $parts = explode(' ', $message);
        $pdo = Conn::get();
        
        if(isset($parts[0]) && $parts[0] == '/banco' && isset($parts[1])) {      
            $banco = $parts[1];

            $stmt = $pdo->prepare("SELECT * FROM ccs WHERE banco LIKE CONCAT('%', :banco, '%') LIMIT 1");
           $stmt->bindParam(":banco", $banco, PDO::PARAM_STR); // Corrigir referência para a classe PDO aqui
           $stmt->execute();

            $ccs = $stmt->fetch();

            if (empty($ccs)) {
                $txt = "Banco Nao Encontrado!";
                $ctx->sendMessage($txt, [
                    "reply_to_message_id" => $ctx->getMessage()->getMessageId(),
                ]);
                return;
            }

            $nivel = $ccs['nivel'];
            $bandeira = $ccs['bandeira'];
            $tipo = $ccs['tipo'];
            $banco = $ccs['banco'];
            $pais = $ccs['pais'];
            $cc = $ccs['cc'];

            $stmt = $pdo->prepare("SELECT * FROM preco WHERE nivel = :nivel"); 
            $stmt->bindParam(":nivel", $nivel, PDO::PARAM_STR); // Corrigir referência para a classe PDO aqui
            $stmt->execute();

            $preco = $stmt->fetch();
            $price = $preco['valor'];

            $txt = "BANCO ENCONTRADO\n\nNIVEL: $nivel\nBANDEIRA: $bandeira\nTIPO: $tipo\nPAIS: $pais\nPRECO: $price\n\nCLIQUE NO BOTAO ABAIXO SOMENTE SE TIVER CERTEZA DA COMPRA!!!";

            $buttons[] = ['text' => "COMPRAR", 'callback_data' => "chkbin $cc $price"];
            $menu['inline_keyboard'] = array_chunk($buttons, 2);

            $ctx->sendMessage($txt, [
                "reply_markup" => $menu,
                "reply_to_message_id" => $ctx->getMessage()->getMessageId(),
            ]);
        }
    }  
}