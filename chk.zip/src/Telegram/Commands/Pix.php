<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use App\Db\Conn;

class Pix
{
    public bool $prt = false;

    public function handler(Context $ctx) {
        $message = $ctx->getMessage()->getText();
        $chat_id = $ctx->getMessage()->getChat()->getId();
        $parts = explode(' ', $message);
        
        if(isset($parts[0]) && $parts[0] == '/pix' && isset($parts[1])) {      
            $amount = $parts[1];  
            $nome = $ctx->getMessage()->getFrom()->getFirstName();
            $banco = "MercadoPago";
            $pdo = Conn::get(); // Conectar ao banco de dados

            $stmt = $pdo->prepare("SELECT * FROM dados_pix WHERE banco = :banco");
            $stmt->bindParam(":banco", $banco, \PDO::PARAM_STR);
            $stmt->execute();

            $fetch = $stmt->fetch();

            $tempo = $fetch['tempo'] ?? 10;
            $min = $fetch['min'] ?? 10;
            $max = $fetch['max'] ?? 1000; // Valor de exemplo para max
            $token = $fetch['token'] ?? '';

            if(empty($token)) {
                $txt = "*⚠️ O BOT ESTÁ SEM PIX AUTOMÁTICO! TENTE O PIX MANUAL DO BOT.*";
                $ctx->sendMessage($txt, ["reply_to_message_id" => $ctx->getMessage()->getMessageId()]);
                
            }

            if(empty($amount)) {
                $txt = "*💠 ADIÇÃO DE SALDO VIA PIX ..."; // Mensagem de instrução
                $ctx->sendMessage($txt, [
                "reply_to_message_id" => $ctx->getMessage()->getMessageId(),
            ]);
               
            }

            if($amount < $min) {
                $txt = "*VALOR MÍNIMO PARA ADIÇÃO AUTOMÁTICA É: R$$min*";
                $ctx->sendMessage($txt, ["reply_to_message_id" => $ctx->getMessage()->getMessageId()]);
               
            }
            
            if($amount > $max) {
                $txt = "*VALOR MÁXIMO PARA ADIÇÃO AUTOMÁTICA É: R$$max*";
                $ctx->sendMessage($txt, ["reply_to_message_id" => $ctx->getMessage()->getMessageId()]);
                
            }
            
            $curl = curl_init();

      curl_setopt_array($curl, [
  
  CURLOPT_URL => "https://pladixoficial.com.br/mercadoPago/createPix.php?accessToken=".$token."&value=".$amount."&time=".$tempo,
  
  CURLOPT_RETURNTRANSFER => true,
  
  ]);
  
  $exec1 = curl_exec($curl);
  
  $exec = json_decode($exec1, true);

  $qr = $exec["qr_code"];

  $id_pix = $exec["id_pix"];

  $tempo = "15";
  
  echo "$exec1";
  echo "$id_pix";

            // Inserir transação no banco de dados
            $data = date("Y-m-d H:i:s");
            $stmt = $pdo->prepare("INSERT INTO pix (chat_id, id_pix, valor, status, data) VALUES (:chat_id, :id_pix, :amount, 'pendente', :data)");
            $stmt->bindParam(':chat_id', $chat_id, \PDO::PARAM_INT);
            $stmt->bindParam(':id_pix', $id_pix, \PDO::PARAM_INT);
            $stmt->bindParam(':amount', $amount, \PDO::PARAM_STR);
            $stmt->bindParam(':data', $data, \PDO::PARAM_STR);
            $stmt->execute();
   
            $txt = "*✅ Transação foi criada*\n\n* 🏷️ Pix Copia e Cola:* $qr\n\n💰 *Valor:* R$$amount\n\n⏰ *A TRANSAÇÃO EXPIRA EM ".$tempo." MINUTOS!*\n⚠️ *CASO O PAGAMENTO SEJA FEITO E NÃO SEJA CREDITADO NA STORE CHAMAR O SUPORTE!*";

            $buttons[] = ['text' => "🔁 VERIFICAR", 'callback_data' => "chkpixv2 $id_pix $amount"];
    
            $menu['inline_keyboard'] = array_chunk($buttons, 2);

            $ctx->sendMessage($txt, [
                "reply_markup" => $menu,
                "reply_to_message_id" => $ctx->getMessage()->getMessageId(),
            ]);
        }
    }
}