<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use App\Db\Conn;
use \PDO;

class Send {
	public bool $prt = false;
	
    public function handler(Context $ctx) {
        $admin = $_ENV['ADMIN'] ?? '';
        $token = $_ENV['BOT_TOKEN'] ?? ''; 
        $chat_id = $ctx->getUpdate()->getMessage()->getChat()->getId();

        if ($chat_id == $admin) {
            $pdo = Conn::get();
            $texto = $ctx->getMessage()->getText();
            $txt = trim(substr($texto, 6));
            $token = $_ENV['BOT_TOKEN'] ?? ''; 
            // Obtendo todos os chat_id da tabela usuario_info
            $stmt = $pdo->query("SELECT chat_id FROM usuario_info");
            $chatIds = $stmt->fetchAll(PDO::FETCH_COLUMN); // Corrigido
            
            $total = count($chatIds);
            $enviados = 0;
            $naoenviados = 0;

            // Inicializar multi curl
            $mh = curl_multi_init();
            $chArray = [];

            foreach ($chatIds as $id) {
                $ch = curl_init();
                $url = "https://api.telegram.org/bot{$_ENV['BOT_TOKEN']}/sendMessage?chat_id={$id}&text=" . urlencode(str_replace('_', '\_', $txt)) . "&parse_mode=Markdown";
           
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_multi_add_handle($mh, $ch);
                $chArray[$id] = $ch;
            }

            // Executar as chamadas simultâneas
            $active = null;
            do {
                $status = curl_multi_exec($mh, $active);
            } while ($active > 0 && $status == CURLM_OK);

            // Coletar os resultados
            foreach ($chArray as $id => $ch) {
                $data = curl_multi_getcontent($ch);
                $response = json_decode($data, true);
                if ($response && $response['ok']) {
                    $enviados++;
                } else {
                    $naoenviados++;
                }

                curl_multi_remove_handle($mh, $ch);
                curl_close($ch);
            }

            // Fechar o handle multi curl
            curl_multi_close($mh);

            // Enviar o resumo
            $resumo = "ℹ️ OPA ENVIAMOS SUA MSG\n\n📁 TOTAL DE IDS: $total\n✅ IDS ENVIADOS: $enviados\n❌ NÃO ENVIADOS: $naoenviados";
$ctx->sendMessage($resumo);
        } else {
            $ctx->sendMessage("❌ Você não tem autorização.");
        }
    }
}