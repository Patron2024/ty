<?php

namespace App\Telegram\Commands;

use Zanzara\Context;
use PDO;
use App\Db\Conn;

class Sql {
    public bool $prt = true;

    public function handler(Context $ctx) {

    
        $pdo = Conn::get();

        // Verificar se a mensagem contém o comando SQL
        $texto = $ctx->getUpdate()->getMessage()->getText();
        if (strpos($texto, "/sql") === 0) {
            $comando = trim(substr($texto, 4));
            
            // Executar o comando SQL fornecido e obter os resultados
            try {
                $stmt = $pdo->query($comando);
                
                if ($stmt !== false) {
                    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $mensagem = "ℹ️ Resultados da consulta:\n\n";
                    foreach ($resultados as $resultado) {
                        $mensagem .= "- " . implode(", ", $resultado) . "\n";
                    }
                } else {
                    $mensagem = "❌ Erro ao executar a consulta SQL.";
                }
            } catch(PDOException $e) {
                $mensagem = "❌ Ocorreu um erro na execução da consulta: " . $e->getMessage();
            }

            // Enviar mensagem com os resultados da consulta
            $ctx->sendMessage($mensagem, ["chat_id" => $chat_id, "parse_mode" => 'Markdown']);
        }
    }
}